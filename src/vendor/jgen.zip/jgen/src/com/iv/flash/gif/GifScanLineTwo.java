package com.iv.flash.gif;

/**
 * This class handles two-bit, packed data for one line of a gif bitmap.
 * As such it is useful for images with up to four colors.
 * They are stored in two bit pairs from high-bit to low-bit in each byte.
 *
 * @author Andrew Watson (Datatask Pty. Ltd.)
 */
class GifScanLineTwo
        extends GifScanLine {

    /**
     * Constuctor with the pixel width specified
     *
     * @param width The number of pixel values that define the width of this line.
     */
    GifScanLineTwo( int width ) {
        d_width = width;
        int size = width >> 2;
        if( (width&0x03)>0 )
            ++size;
        d_data = new byte[size];
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you want.
     * @return The integer value of the pixel requested.
     */
    int get( int index ) {
        int bindex = index >> 2;
        switch( index&0x03 ) {
            case 0:
                return Gif.unsignedByte(d_data[bindex]) >> 6;
            case 1:
                return (Gif.unsignedByte(d_data[bindex]) >> 4)&0x03;
            case 2:
                return (Gif.unsignedByte(d_data[bindex]) >> 2)&0x03;
            case 3:
                return Gif.unsignedByte(d_data[bindex])&0x03;
        }
        return 0;
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you wish to set.
     * @param value The value you wish to set the specified pixel to.
     */
    void set( int index, int value ) {
        int bindex = index >> 1;
        switch( index&0x01 ) {
            case 0:
                d_data[bindex] |= (byte) 0x3F; // Clear the bits
                d_data[bindex] |= (byte) (value << 6);
                break;
            case 1:
                d_data[bindex] |= (byte) 0xCF;
                d_data[bindex] |= (byte) ((value << 4)&0x30);
                break;
            case 2:
                d_data[bindex] |= (byte) 0xF3;
                d_data[bindex] |= (byte) ((value << 2)&0x0C);
                break;
            case 3:
                d_data[bindex] |= (byte) 0xFC;
                d_data[bindex] |= (byte) (value&0x03);
                break;
        }
    }
}

;
