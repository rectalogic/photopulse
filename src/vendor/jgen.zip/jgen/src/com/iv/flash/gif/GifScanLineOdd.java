package com.iv.flash.gif;

/**
 * This class handles one to eight bit, packed data for one line of a gif bitmap.
 * As such it is useful for all images from 2 to 256 colors.
 * They are stored from high-bit to low-bit in each byte.
 *
 * @author Andrew Watson (Datatask Pty. Ltd.)
 */
class GifScanLineOdd
        extends GifScanLine {

    /**
     * Constuctor with the pixel width specified
     *
     * @param width The number of pixel values that define the width of this line.
     * @param depth The number of bits per pixel that need to be stored.
     */
    GifScanLineOdd( int width, int depth ) {
        d_depth = (depth<8)? depth: 8; // only allow up to 8 bits per pixel
        d_width = width;

        // Calculate how many bytes we need to hold all the bits
        int bits = width*depth;
        int size = bits >> 3;
        if( (bits&0x7) + depth>8 )
            ++size;
        d_data = new byte[size];
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you want.
     * @return The integer value of the pixel requested.
     */
    int get( int index ) {
        int first_bit = (d_depth*index);
        int first_byte = first_bit >> 3;
        // get two bytes (so they must contain the value)
        int value = ((first_byte + 1)<d_data.length)
                ? Gif.unsignedShort(d_data[first_byte + 1], d_data[first_byte])
                : Gif.unsignedShort((byte) 0x00, d_data[first_byte]);

        // scroll the value down to where it should be
        value = value >> (16 - (first_bit&0x07) - d_depth);
        // mask off any unwanted bits;
        value &= (0xFF >> (8 - d_depth));

        return value;
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you wish to set.
     * @param value The value you wish to set the specified pixel to.
     */
    void set( int index, int value ) {
        int bit = (d_depth*index) + d_depth;
        for( int i = 0; i<d_depth; ++i ) {
            int cur_byte = (--bit) >> 3;
            int cur_bit = bit&0x07;
            if( (value&0x01)>0 ) // set bit
                d_data[cur_byte] |= (0x80 >> cur_bit);
            else
                d_data[cur_byte] &= (0xFF7F >> cur_bit);
        }
    }

    private int d_depth;		// The number of bits per pixel
}

;
