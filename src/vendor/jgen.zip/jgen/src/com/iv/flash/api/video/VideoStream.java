/*
 * $Id: VideoStream.java,v 1.2 2002/11/26 23:10:42 skavish Exp $
 *
 * ===========================================================================
 *
 * The JGenerator Software License, Version 1.0
 *
 * Copyright (c) 2000 Dmitry Skavish (skavish@usa.net). All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *    "This product includes software developed by Dmitry Skavish
 *     (skavish@usa.net, http://www.flashgap.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The name "The JGenerator" must not be used to endorse or promote
 *    products derived from this software without prior written permission.
 *    For written permission, please contact skavish@usa.net.
 *
 * 5. Products derived from this software may not be called "The JGenerator"
 *    nor may "The JGenerator" appear in their names without prior written
 *    permission of Dmitry Skavish.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL DMITRY SKAVISH OR THE OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

package com.iv.flash.api.video;

import com.iv.flash.api.FlashDef;
import com.iv.flash.api.FlashItem;
import com.iv.flash.parser.Parser;
import com.iv.flash.util.*;

import java.io.PrintStream;

/**
 * DefineVideoStream
 *
 * @author Dmitry Skavish
 */
public class VideoStream extends FlashDef {

    private int framesNum;      // number of video frames
    private int width;          // width in pixels
    private int height;         // height in pixels

    // 00: use VIDEOPACKET value
    // 01: off
    // 10: on
    // 11: reserved
    private byte deblocking;

    private boolean isSmoothing;
    private byte codecID;

    public VideoStream() {
    }

    public int getFramesNum() {
        return this.framesNum;
    }

    public void setFramesNum( int framesNum ) {
        this.framesNum = framesNum;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void setWidth( int width ) {
        this.width = width;
    }

    public void setHeight( int height ) {
        this.height = height;
    }

    public int getDeblocking() {
        return deblocking;
    }

    public void setDeblocking( int deblocking ) {
        this.deblocking = (byte) deblocking;
    }

    public boolean isSmoothing() {
        return this.isSmoothing;
    }

    public void setSmoothing( boolean isSmoothing ) {
        this.isSmoothing = isSmoothing;
    }

    public int getCodedID() {
        return codecID;
    }

    public void setCodecID( int codecID ) {
        this.codecID = (byte) codecID;
    }

    public static VideoStream parse( Parser p ) {
        VideoStream v = new VideoStream();
        v.setID(p.getUWord());
        v.setFramesNum(p.getUWord());
        v.setWidth(p.getUWord());
        v.setHeight(p.getUWord());
        int flags = p.getUByte();
        v.setDeblocking((flags&0x06) >> 1);
        v.setSmoothing((flags&0x01) != 0);
        v.setCodecID(p.getUByte());
        return v;
    }

    public int getTag() {
        return Tag.DEFINEVIDEOSTREAM;
    }

    public void printContent( PrintStream out, String indent ) {
        out.println(indent + "DefineVideoStream: id=" + getID() + ", name='" + getName() + "'");
        out.println(indent + "    size=" + width + "x" + height + ", frames=" + framesNum);
        out.println(indent + "    deblocking=" + deblocking + ", smoothing=" + isSmoothing + ", codecID=" + codecID);
    }

    public boolean isConstant() {
        return true;
    }

    protected FlashItem copyInto( FlashItem item, ScriptCopier copier ) {
        super.copyInto(item, copier);
        ((VideoStream) item).framesNum = framesNum;
        ((VideoStream) item).width = width;
        ((VideoStream) item).height = height;
        ((VideoStream) item).deblocking = deblocking;
        ((VideoStream) item).isSmoothing = isSmoothing;
        ((VideoStream) item).codecID = codecID;
        return item;
    }

    public void write( FlashOutput fob ) {
        fob.writeTag(getTag(), 10);
        fob.writeDefID(this);
        fob.writeWord(framesNum);
        fob.writeWord(width);
        fob.writeWord(height);
        fob.writeByte(((deblocking << 1)&0x06)|(isSmoothing? 1: 0));
        fob.writeByte(codecID);
    }
}

