package com.iv.flash.gif;

import java.util.Vector;

/**
 * Stores and retrieves code strings, as used in LZW compression/decompression.
 *
 * @author Andrew Watson (Datatask Pty. Ltd.)
 * @see CodeString
 */
class LZWCodeTable {

    /**
     * Default constructor.
     */
    LZWCodeTable() {
    }

    /**
     * Set the value that defines the first unknown code value for this LZW table.
     * The first code, is the first value that identifies a sequence of known
     * codes.  Any code below this is known by the encoder/decoder algorithm and
     * needs to be treated as such.  This value must be set before any other
     * methods are called.
     *
     * @param code The value that defines the first unknown code.
     */
    void set_first_code( int code ) {
        d_first_code = code;
    }

    /**
     * Retrieve the code string that the specified code represents.
     * If the specified code is less than the first code, then a string of one
     * byte is returned, otherwise it will return the string stored.
     *
     * @param code The code to get the translation for.
     * @return The code string that corresponds to the code given.
     */
    CodeString get_translation( int code ) {
        if( code<d_first_code )
            return new CodeString(1, (byte) code);
        code -= d_first_code;
        if( code<d_code_table.size() )
            return new CodeString((CodeString) d_code_table.get(code));

        // It is actually an error to get here, as the code should be known.
        return new CodeString();
    }

    /**
     * Append a code string to the end of the stored list for later retrieval.
     *
     * @param codes The code string to store.
     */
    void add_translation( CodeString codes ) {
        d_code_table.add(new CodeString(codes));
    }

    /**
     * Check if a code is known in this table.
     *
     * @param code The value to check, to see if it has a known translation.
     * @return true if the code is known, false otherwise.
     */
    boolean known_code( int code ) {
        return ((code<d_first_code)
                || ((code - d_first_code)<d_code_table.size()));
    }

    /**
     * Remove all code strings from this table
     */
    void clear() {
        d_code_table.clear();
    }

    /**
     * Check how many code strings we have stored.
     */
    int size() {
        return d_code_table.size();
    }

    private int d_first_code = 0;			// First unknown code.
    private Vector d_code_table = new Vector();	// code strings we have stored.
}

;
