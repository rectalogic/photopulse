package com.iv.flash.gif;

import com.iv.flash.api.AlphaColor;
import com.iv.flash.parser.DataMarker;
import com.iv.flash.util.FlashBuffer;

import java.io.*;
import java.util.zip.Deflater;

/**
 * This class is the public interface to obtain a gif image in flash format.
 *
 * @author Andrew Watson (Datatask Pty. Ltd.)
 */
public class GifConverter {

    public int getColorTableSize() {
        return d_palette.size() - 1;
    }

    public int getWidth() {
        return d_table_image.width();
    }

    public int getHeight() {
        return d_table_image.height();
    }

    public DataMarker getZlibData() throws IOException {
        return getZlibData(d_palette, d_table_image);
    }

    public boolean isAlpha() {
        return d_table_image.controlExtension() == null
                ? false
                : d_table_image.controlExtension().hasTransparency();
    }

    /**
     * Launch the loadGIF routine
     *
     * @param buffer
     * @exception IOException
     */
    public void doRead( byte[] buffer )
            throws IOException, GifException {
        doRead(new ByteArrayInputStream(buffer, 0, buffer.length));
    }

    public void doRead( FlashBuffer fob )
            throws IOException, GifException {
        doRead(fob.getInputStream());
    }

    public void doRead( InputStream input )
            throws IOException, GifException {
        d_image.read(input);

        // Get the table based image block (defines the picture)
        d_table_image = d_image.getFirstImage();

        if( d_table_image == null )
            throw(new GifException("Missing Image!"));

        // Determine the palette to use
        d_palette = d_image.getPaletteFor(d_table_image);

        if( d_palette == null )
            throw(new GifException("Missing Palette"));
    }

    public static DataMarker getZlibData(
            GifPalette palette
            , GifTableBasedImage image ) {
        int width = image.width();
        // what has to be added to align each line on a 4 byte boundry
        int extra_width = (width&0x03) == 0? 0: (4 - (width&0x03));
        int maxpixels = (width + extra_width)*image.height();

        GifGraphicControlExtension control_extension = image.controlExtension();

        boolean has_alpha = (control_extension == null)
                ? false
                : control_extension.hasTransparency();

        int length = (has_alpha)? (4*palette.size()): (3*palette.size());
        length += maxpixels;

        // Flash buffer to build the data in.
        FlashBuffer buffer = new FlashBuffer(length);

        // copy in the color data
        if( has_alpha ) {
            palette.set(control_extension.transparencyIndex()
                        , new AlphaColor(0, 0, 0, 0));

            for( int i = 0; i<palette.size(); ++i )
                palette.get(i).writeRGBA(buffer);
        } else {
            for( int i = 0; i<palette.size(); ++i )
                palette.get(i).writeRGB(buffer);
        }

        // prepare any padding
        byte[] padding = new byte[extra_width];
        for( int i = 0; i<extra_width; ++i )
            padding[i] = 0x00;

        // Add all the lines of data
        for( int i = 0; i<image.height(); ++i ) {
            // add the pixel data
            byte[] data = image.getLine(i).rawData();
            buffer.writeArray(data, 0, data.length);

            // add any padding data
            buffer.writeArray(padding, 0, padding.length);
        }

        // create storage for deflated data
        byte[] d_data = new byte[length];
        Deflater def = new Deflater();
        def.setInput(buffer.getBuf());
        def.finish();
        int deflatedSize = def.deflate(d_data); // compress the data
        return new DataMarker(d_data, 0, deflatedSize);
    }

    private int d_image_index = -1;

    private GifImage d_image = new GifImage();
    private GifTableBasedImage d_table_image = null;
    private GifPalette d_palette = null;
}
