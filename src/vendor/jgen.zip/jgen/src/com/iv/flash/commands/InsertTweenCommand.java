/*
* This object dynamically inserts motion, rotation, and scale tweens into a
* Flash movie.
*
* It can also be used to insert and position multiple symbols into a Flash 
* movie, similiar to the plot object.
*/

package com.iv.flash.commands;

import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.util.Vector;

import com.iv.flash.api.*;
import com.iv.flash.context.Context;
import com.iv.flash.context.StandardContext;
import com.iv.flash.util.*;

public class InsertTweenCommand extends GenericCommand
{

  public InsertTweenCommand()
  {
  }

  public void doCommand(
    FlashFile file
  , Context context
  , Script parent
  , int frame_no
  ) throws IVException
  {
    data_source = getParameter(context, "datasource");
    try
    {
      UrlDataSource urldatasource = new UrlDataSource(data_source, file);
      data_arrays = urldatasource.getData();
    }
    catch(IOException ioexception)
    {
      throw new IVException("1_00a"
      , new Object[] { data_source, getCommandName() }, ioexception);
    }
    if(data_arrays.length < 1)
    {
      throw new IVException("1_00b"
      , new Object[] { data_source, getCommandName() });
    }
   
    // set all the references to the columns
    setColumnIndexes(data_arrays[0]);

    // Get the instance
    Instance inst = getInstance();
    
    // Get the depth for all of the insertions...
    int layer = inst.depth;

    // Remove the instance from the script...
    Frame frame = parent.getFrameAt(frame_no);
    frame.remove(inst);

    parent.reserveLayers(layer, data_arrays.length);

    // For each set of data (skipping the header row of course)
    for(int row = 1; row < data_arrays.length; ++row)
    {
      insertTween(file, context, parent, data_arrays[row]
      , layer++);
    }
  }

  private void insertTween(
    FlashFile flashfile
  , Context context
  , Script command_script
  , String[] data_array
  , int layer
  ) throws IVException
  {
    // Get the script we are to insert
    String clip_name = data_array[clip_column];
    Script child_script = flashfile.getScript(clip_name);
    if(child_script == null)
    {
      Log.logRB("1_007"
      , new Object[] { clip_name, getCommandName() });
      return;
    }
    child_script = child_script.copyScript();
    child_script.clearProcessed();

    /*
    * Now that we have found the symbol, process it in order to ensure that
    * any Generator variables or objects contained within the symbol, are
    * processed.
    *
    * First we loop through all of the custom column headings added by the
    * user and place their value in the Context so they can be accessed
    * when the Script is processed.
    */
    StandardContext child_context = new StandardContext(context);
    for(int j = 0; j < var_indexes.size(); j++)
    {
      int index = ((Integer)var_indexes.elementAt(j)).intValue();
      child_context.setValue(data_arrays[0][index], data_array[index]);
    }
    flashfile.processScript(child_script, child_context);

    // Get all the insertion data for the instance we are inserting
    AffineTransform s_matrix = getStartMatrix(data_array);
    AffineTransform e_matrix = getEndMatrix(data_array);
      
    int start_frame = (s_frame_column == -1) 
    ? 0
    : Util.toInt(data_array[s_frame_column], 0);

    int end_frame = (e_frame_column == -1) 
    ? start_frame + 1
    : Util.toInt(data_array[e_frame_column], start_frame + 1);

    String instance_name = (instance_name_column == -1)
    ? null
    : data_array[instance_name_column];

    command_script.addTweening(child_script, layer
    , start_frame, s_matrix, null
    , end_frame, e_matrix, null
    , instance_name);
/*
    try
    {
      flashfile.setScriptMarker();
    }
    catch(Throwable throwable)
    {
      throw new IVException("1_004"
      , new Object[] { getCommandName() });
    }
*/
  }

  /*
  * This method takes a multi dimensional array data source, and parses through
  * its column labels / heading looking for spefic ones. If it finds a column
  * label that it is looking for, it sets the index of that labels position.
  *
  * This makes it easier to work with the data source in the object.
  */
  private void setColumnIndexes(String[] heading_array) 
  throws IVException
  {
    for (int i = 0; i < heading_array.length; ++i)
    {
      if (heading_array[i].trim().equalsIgnoreCase("template_file"))
      {
	  template_file_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("clip"))
      {
	  clip_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("startX"))
      {
	  x_start_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("startY"))
      {
	  y_start_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("endX"))
      {
	  x_end_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("endY"))
      {
	  y_end_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("startFrame"))
      {
	  s_frame_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("endFrame"))
      {
	  e_frame_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("instanceName"))
      {
	  instance_name_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("startXScale"))
      {
	  x_start_scale_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("startYScale"))
      {
	  y_start_scale_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("endXScale"))
      {
	  x_end_scale_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("endYScale"))
      {
	  y_end_scale_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("startAngle"))
      {
	  s_angle_column = i;
	  continue;
      }
      if (heading_array[i].trim().equalsIgnoreCase("endAngle"))
      {
	  e_angle_column = i;
	  continue;
      }

      // Not a known column... add it to the list of variables to pass on.
      var_indexes.addElement(new Integer(i));
    }
    // Check for required columns 
    if(clip_column == -1)
    {
      throw new IVException("1_00d"
      , new Object[] { getCommandName(), "Clip", data_source });
    }
    if(s_frame_column == -1)
    {
      throw new IVException("1_00d"
      , new Object[] { getCommandName(), "startFrame", data_source });
    }
    if(e_frame_column == -1)
    {
      throw new IVException("1_00d"
      , new Object[] { getCommandName(), "endFrame", data_source });
    }
  }

  private AffineTransform getStartMatrix(String[] val_array)
  {
    return getMatrix(val_array, x_start_column, y_start_column, s_angle_column
    , x_start_scale_column, y_start_scale_column);
  }

  private AffineTransform getEndMatrix(String[] val_array)
  {
    return getMatrix(val_array, x_end_column, y_end_column, e_angle_column
    , x_end_scale_column, y_end_scale_column);
  }

  private AffineTransform getMatrix(
    String[] val_array
  , int x_col
  , int y_col
  , int angle_col
  , int x_scale_col
  , int y_scale_col)
  {
    AffineTransform base = getInstance().matrix;

    double x = (base != null) ? base.getTranslateX() : 0.0;
    if (x_col != -1) 
      x = Util.toDouble( val_array[x_col], x);
    
    double y = (base != null) ? base.getTranslateY() : 0.0;
    if (y_col != -1) 
      y = Util.toDouble( val_array[y_col], y);
    
    // Get the base translation matrix
    AffineTransform xform = AffineTransform.getTranslateInstance(x, y);
    
    // Rotate it if needed
    if (angle_col != -1)
      xform.rotate( Math.toRadians( Util.toDouble(val_array[angle_col], 0.0)));
      
    // Scale it if needed
    if (x_scale_col != -1 || y_scale_col != -1)
    {
      double x_scale = (x_scale_col == -1) 
      ? 1.0
      : Util.toDouble( val_array[x_scale_col], 1.0);

      double y_scale = (y_scale_col == -1) 
      ? 1.0
      : Util.toDouble( val_array[y_scale_col], 1.0);
      
      xform.scale(x_scale, y_scale);
    }
    return xform;
  }
  
  private int clip_column = -1;
  private int x_start_column = -1;
  private int y_start_column = -1;
  private int x_end_column = -1;
  private int y_end_column = -1;
  private int s_frame_column = -1;
  private int e_frame_column = -1;
  private int instance_name_column = -1;
  private int x_start_scale_column = -1;
  private int y_start_scale_column = -1;
  private int x_end_scale_column = -1;
  private int y_end_scale_column = -1;
  private int s_angle_column = -1;
  private int e_angle_column = -1;
  private int template_file_column = -1;

  private String data_source = null;
  private String data_arrays[][];

  Vector var_indexes = new Vector();
}
