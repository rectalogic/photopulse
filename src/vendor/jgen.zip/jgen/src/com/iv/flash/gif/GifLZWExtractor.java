package com.iv.flash.gif;

import java.io.IOException;
import java.io.InputStream;

class GifLZWExtractor {

    GifLZWExtractor( InputStream ins, int min_code_size ) {
        // setup the bit extraction data
        d_ins = ins;

        d_min_bits = min_code_size + 1;
        d_clear_code = 1 << min_code_size;
        d_end_code = d_clear_code + 1;
        resetBits();

        // Steps taken from LZW Explained by Steve Blackstock
        // [1] Initialize string table;
        d_string_table = new LZWCodeTable();
        d_string_table.set_first_code(d_end_code + 1);
    }

    CodeString readNextString()
            throws IOException, GifException {
        int code;

        // [2] get first code: <code>;
        // [5] <code> <- next code in codestream;
        while( (code = getNextCode()) == d_clear_code ) {
            d_string_table.clear();
            resetBits();
            d_old_str.clear();
            d_allow_clear = true;
        }

        if( code == d_end_code )
            return null;

        if( d_old_str.size() == 0 ) {
            // [4] <old> = <code>;
            d_old_str.push_back((byte) code);

            // [3] output the string for <code> to the charstream;
            return d_old_str;
        }

        // [6] does <code> exist in the string table?
        if( d_string_table.known_code(code) ) {
            // (yes: output the string for <code> to the charstream;
            CodeString n_str = d_string_table.get_translation(code);
            // 	[...] <- translation for <old>;
            // n_str is now what we want to add
            // 	K <- first character of translation for <code>;
            byte K = n_str.front();
            // 	add [...]K to the string table;
            d_old_str.push_back(K);
            d_string_table.add_translation(d_old_str);
            // 	<old> <- <code>;
            // d_old_str is now what we want to add
            d_old_str = n_str;
        } else {
            //(no: [...] <- translation for <old>;
            //	K <- first character of [...];
            byte K = d_old_str.front();
            //	output [...]K to charstream and add it to string table;
            d_old_str.push_back(K);
            // d_old_str is now what we want to add
            d_string_table.add_translation(d_old_str);
            //	<old> <- <code>
            if( !d_string_table.known_code(code) )
                throw new GifException("Error, new code is not in sequence.");
        }

        // Check if we need to increase the size
        if( (d_string_table.size() + d_end_code)>=d_max_code ) {
            if( d_max_code == 0xFFF ) {
                if( d_allow_clear )
                    d_allow_clear = false;
                else
                    throw new GifException("Error, clear code is missing.");
            } else
                increaseMax();
        }
        // NOTE : the d_old_str is always set to the string we want output
        return d_old_str;
    } // [7] go to [5];

    /**
     * Read the next code from the input stream.
     *
     * @return the next code as an integer.
     */
    private int getNextCode()
            throws IOException {
        int bits_needed = d_bits; 	// The number of bits we still need
        int code;			// The storage for the value we return

        // read more data if needed
        if( (d_buf_pos>=d_buf_len) && !readBlock() )
            return 0;

        // start with any unused bits
        code = (Gif.unsignedByte(d_buf[d_buf_pos]) >> d_bits_used);
        bits_needed -= (8 - d_bits_used);	// recalculate the bits needed

        // add any necessary remaining bits
        while( bits_needed>0 ) {
            ++d_buf_pos;
            // read more data if needed
            if( (d_buf_pos>=d_buf_len) && !readBlock() )
                return 0;
            code |= (Gif.unsignedByte(d_buf[d_buf_pos]) << (d_bits - bits_needed));
            bits_needed -= 8;
        }

        // set the bits used for the next time
        if( bits_needed == 0 ) {
            ++d_buf_pos;
            d_bits_used = 0;
        } else
            d_bits_used = 8 + bits_needed;

        // mask off the bits
        code &= d_max_code;

        return code;
    }

    /**
     * Increment the number of bits to be read by this data buffer.
     */
    private void increaseMax() {
        ++d_bits;
        d_max_code = (0xFFFF >> (16 - d_bits));
    }

    /**
     * Return the number of bits to be read to the original value.
     */
    private void resetBits() {
        d_bits = d_min_bits;
        d_max_code = (0xFFFF >> (16 - d_bits));
    }

    /**
     * Read a block of data that holds the codes this class will retrieve
     *
     * @return true if the block reading was successful, false otherwise.
     */
    private boolean readBlock()
            throws IOException {
        d_buf_len = Gif.unsignedByte(d_ins);

        if( d_ins.read(d_buf, 0, d_buf_len) != d_buf_len )
            return false;

        d_buf_pos = 0;
        return true;
    }

    private byte[] d_buf = new byte[256];	// buffer to store a block of data
    private int d_buf_pos = 0;		// current position in the buffer
    private int d_buf_len = 0;		// how many bytes in this block

    private int d_min_bits;		// minimum number of bits to read
    private int d_clear_code;		// code that should reset this class
    private int d_end_code;		// code that marks the end of this gif
    private int d_max_code;		// maximum code that will fit in d_bits

    private int d_bits;			// number of bits to read at the moment
    private int d_bits_used = 0;		// number of bits used in current byte

    private InputStream d_ins;		// source for our data
    private LZWCodeTable d_string_table = null;
    private CodeString d_old_str = new CodeString();
    private boolean d_allow_clear = true;
}

;
