package com.iv.flash.gif;

/**
 * This class handles eight bit data for one line of a gif bitmap.
 * As such it is useful for VGA images (images with up to 256 colors).
 * They are stored with one value per byte.
 *
 * @author Andrew Watson (Datatask Pty. Ltd.)
 */
class GifScanLineEight
        extends GifScanLine {

    /**
     * Constuctor with the pixel width specified
     *
     * @param width The number of pixel values that define the width of this line.
     */
    GifScanLineEight( int width ) {
        d_width = width;
        d_data = new byte[width];
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you want.
     * @return The integer value of the pixel requested.
     */
    int get( int index ) {
        return d_data[index];
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you wish to set.
     * @param value The value you wish to set the specified pixel to.
     */
    void set( int index, int value ) {
        d_data[index] = (byte) value;
    }
}

;
