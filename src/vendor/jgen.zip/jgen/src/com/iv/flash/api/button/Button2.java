/*
 * $Id: Button2.java,v 1.4 2002/11/26 23:10:40 skavish Exp $
 *
 * ===========================================================================
 *
 * The JGenerator Software License, Version 1.0
 *
 * Copyright (c) 2000 Dmitry Skavish (skavish@usa.net). All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *    "This product includes software developed by Dmitry Skavish
 *     (skavish@usa.net, http://www.flashgap.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The name "The JGenerator" must not be used to endorse or promote
 *    products derived from this software without prior written permission.
 *    For written permission, please contact skavish@usa.net.
 *
 * 5. Products derived from this software may not be called "The JGenerator"
 *    nor may "The JGenerator" appear in their names without prior written
 *    permission of Dmitry Skavish.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL DMITRY SKAVISH OR THE OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

package com.iv.flash.api.button;

import com.iv.flash.api.FlashItem;
import com.iv.flash.api.action.Program;
import com.iv.flash.parser.Parser;
import com.iv.flash.util.*;

public class Button2 extends Button {

    public static final int TrackAsMenu = 1;
    public static final int TrackAsButton = 0;

    protected int track;

    public Button2() {
    }

    public int getTag() {
        return Tag.DEFINEBUTTON2;
    }

    public void setTrackAs( int track ) {
        this.track = track;
    }

    public int getTrackAs() {
        return track;
    }

    public static Button2 parse2( Parser p ) {
        Button2 o = new Button2();
        o.setID(p.getUWord());
        o.track = p.getUByte();
        int actionsOffset = p.getPos();
        int nextOff = p.getUWord();
        o.parseButtonRecords(p, true);

        // parse action conditions
        while( nextOff>0 ) {
            actionsOffset += nextOff;
            p.setPos(actionsOffset);
            nextOff = p.getUWord();
            int endOff = nextOff == 0? p.getTagEndPos(): actionsOffset + nextOff;
            int cond = p.getUWord();
            Program prog = new Program(p.getBuf(), p.getPos(), endOff);
            o.addActionCondition(new ActionCondition(cond, prog));
        }

        return o;
    }

    public void write( FlashOutput fob ) {
        int pos = fob.getPos();
        fob.skip(6);
        fob.writeDefID(this);
        fob.writeByte(track);

        int actionOffsetPos = fob.getPos();
        fob.writeWord(0);

        writeButtonRecords(fob);

        for( int i = 0; i<conditions.size(); i++ ) {
            ActionCondition ac = (ActionCondition) conditions.elementAt(i);
            fob.writeWordAt(fob.getPos() - actionOffsetPos, actionOffsetPos);
            actionOffsetPos = fob.getPos();
            fob.writeWord(0);
            ac.write(fob);
        }

        fob.writeLongTagAt(getTag(), fob.getPos() - pos - 6, pos);

        writeExternals(fob);      // 02/08/01 by sd
    }

    protected FlashItem copyInto( FlashItem item, ScriptCopier copier ) {
        super.copyInto(item, copier);
        ((Button2) item).track = track;
        return item;
    }

    public FlashItem getCopy( ScriptCopier copier ) {
        return copyInto(new Button2(), copier);
    }
}

