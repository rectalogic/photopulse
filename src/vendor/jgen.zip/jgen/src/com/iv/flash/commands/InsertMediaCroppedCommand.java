package com.iv.flash.commands;

import com.iv.flash.api.*;
import com.iv.flash.api.image.Bitmap;
import com.iv.flash.api.image.JPEGBitmap;
import com.iv.flash.api.shape.FillStyle;
import com.iv.flash.api.shape.Shape;
import com.iv.flash.context.Context;
import com.iv.flash.util.*;

import java.awt.geom.AffineTransform;
import java.io.IOException;

public class InsertMediaCroppedCommand extends GenericCommand {

    public InsertMediaCroppedCommand() {
    }

    public void doCommand(
            FlashFile file
            , Context context
            , Script parent
            , int frame
            ) throws IVException {
        // Get the command instance
        Instance inst = getInstance();

        // Get the name of the image being inserted.
        String media_name = getParameter(context, "name", "").toLowerCase();

        // Make sure that the user has specified something for the image.
        if( media_name.equals("") ) {
            throw new IVException("Unable to get media_name"
                                  , new Object[]{"name", getCommandName()});
        }

// Kludge for now
//if (media_name.startsWith("c:"))
//  media_name = "\\\\kenny" + media_name.substring(2);

        // Get the variables from the Context.
        int scale = 20;
        int xpos = getIntParameter(context, "xpos", 0)*scale;
        int ypos = getIntParameter(context, "ypos", 20)*scale;
        boolean crop = getBoolParameter(context, "crop", true);
        int xoff = getIntParameter(context, "xoff", 0)*scale;
        int yoff = getIntParameter(context, "yoff", 0)*scale;
        int width = getIntParameter(context, "width", 640)*scale;
        int height = getIntParameter(context, "height", 460)*scale;
        double xscale = (double) getIntParameter(context, "xscale", 100)/100.0;
        double yscale = (double) getIntParameter(context, "yscale", 100)/100.0;
        String instancename = getParameter(context, "instancename", "");

        // Add the media file to the flash file resources
        Object media;
        try {
            media = file.addExternalMedia(media_name, false);
        } catch( IOException e ) {
            throw new IVException(Resource.ERRCMDFILEREAD
                                  , new Object[]{media_name, getCommandName()}, e);
        }

        // Reposition the generator object to the origin
        inst.matrix = AffineTransform.getTranslateInstance(xpos, ypos);

        if( instancename != null && !instancename.equals("") ) {
            inst.name = instancename;
        }

        // select path based on media type
        if( media instanceof FlashFile ) {
            Script script;
            // insert flash movie
            FlashFile flashFile = (FlashFile) media;
            synchronized( flashFile ) {
                script = flashFile.getMainScript();
                script.resetMain();
//	if( flashFile.isTemplate() )
//	{
                script.removeFileDepGlobalCommands();
                script = script.copyScript();
//	}
            }

//      if( flashFile.isTemplate() )
            file.processScript(script, context);

            inst.setScript(script);

            if( crop ) {
                addMask(parent, frame, inst, GeomHelper.newRectangle(0, 0, width, height));
                inst.matrix.translate(xoff, yoff);
            }
        } else if( media instanceof Bitmap ) {
            // cast to bitmap object for easy reference
            Bitmap bm = (Bitmap) media;
            if( !crop ) {
                width = bm.getWidth()*scale;
                height = bm.getHeight()*scale;
            }

            // Set the quality for JPEG images
            if( media instanceof JPEGBitmap ) {
                float quality = (float) getIntParameter(context, "quality", 80)/100.0f;
                JPEGBitmap jbm = (JPEGBitmap) media;
                jbm.processImage(quality);
            }

            Shape shape = new Shape();
            shape.setFillStyle0(0);

            // Translate by -1/2 pixel (10 twips) to avoid Flash rendering
            // with top/left pixels duplicated and bottom right pixels truncated.
            AffineTransform fillMatrix = AffineTransform.getTranslateInstance(xoff, yoff);

            // Scale from twips to pixels
            fillMatrix.scale(scale, scale);

            // Set bitmap fill
            shape.setFillStyle1(FillStyle.newTiledBitmap(bm, fillMatrix));

            shape.drawRectangle(0, 0, width, height);
            shape.setBounds(GeomHelper.newRectangle(0, 0, width, height));

            // This instance is what will be added to the movie
            Instance media_instance = new Instance();
            media_instance.def = shape;
            media_instance.matrix = null;
            Script script = inst.copyScript();
            Frame myFrame = script.newFrame();
            myFrame.addInstance(media_instance, 1);
//      inst.setScript(script);
        } else {
            // Error... unknown media type
        }
        inst.matrix.scale(xscale, yscale);
    }
}

;
