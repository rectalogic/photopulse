package com.iv.flash.gif;

import java.io.*;

class GifApplicationExtension
        extends GifSpecialBlock {

    public GifApplicationExtension() {
    }

    int blockLabel() {
        return Gif.APPLICATION_EXTENSION;
    }

    public void read( InputStream ins )
            throws IOException, GifException {
        if( Gif.unsignedByte(ins) != Gif.APPLICATION_EXTENSION )
            throw new GifException("Reading Application Extension in error.");
        if( Gif.unsignedByte(ins) != 11 )
            throw new GifException("Incorrect block size.");

        if( ins.read(d_buf, 0, 11) != 11 ) {
            throw new GifException(
                    "Not enough bytes available for Application Extension.");
        }

        d_application_identifier = new String(d_buf, 0, 8);
        d_application_authentication_code = new String(d_buf, 8, 3);

        readDataBlocks(ins, d_application_data);
    }

    public void write( OutputStream outs )
            throws IOException, GifException {
        throw new GifException("Not implemented Yet");
    }

    // legend:                    (1)   if present, at most one occurrence
    //    	                (*)   zero or more occurrences
    // 	                        (+)   one or more occurrences
    //
    // Block Name                 Required   Label       Ext.   Vers.
    // Application Extension      Opt. (*)   0xFF (255)  yes    89a
    private String d_application_identifier = null;
    private String d_application_authentication_code = null;
    private StringBuffer d_application_data = new StringBuffer();

    private byte[] d_buf = new byte[16];
}

;
