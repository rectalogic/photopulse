/*
 * $Id: SoundStreamBuilder.java,v 1.4 2004/09/28 00:39:28 awason Exp $
 *
 * ===========================================================================
 *
 */

package com.iv.flash.api.sound;

import com.iv.flash.parser.DataMarker;
import com.iv.flash.url.IVUrl;
import com.iv.flash.util.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class SoundStreamBuilder {

    /** Holds the MP3 samples are read from */

    private MP3Helper mp3;

    /** Calculated ideal samples per block: sampleRate / frameRate */

    private int idealSamplesPerBlock = 0;

    /** Frame rate of containing file */

    private float frameRate = 0;

    /** Total samples completed so far */

    private int samplesCompleted = 0;

    /** Total sound blocks completed so far */

    private int blocksCompleted = 0;

    /** Saves us the trouble of mark and reset */

    private byte[] firstFrameCache = null;

    /** Data size (skavish 05/03/2001) */
    private int dataSize = 0;

    /** Create SoundStreamBuilder from url and frame rate */

    public static SoundStreamBuilder newSoundStreamBuilder( IVUrl url, int rate ) throws IOException, IVException {
        return newSoundStreamBuilder(Util.readUrl(url), rate);
    }

    /** Create a SoundStreamBuilder for the provided buffer and frame rate */

    public static SoundStreamBuilder newSoundStreamBuilder( FlashBuffer fob, int rate ) throws IOException, IVException {
        SoundStreamBuilder o = new SoundStreamBuilder();

        o.mp3 = new MP3Helper(fob);
        // Convert from 8:8 fixed point framerate to float
        o.frameRate = (float)rate / (1<<8);
        o.dataSize = fob.getSize();

        return o;
    }

    /** Get the SoundStreamHead object for this sound */

    public SoundStreamHead getSoundStreamHead() throws IOException, IVException {
        SoundStreamHead o = new SoundStreamHead();

        firstFrameCache = mp3.nextFrame();

        o.streamCompression = Sound.COMPRESS_MP3;

        // Set the rate from the MP3's frequency

        switch( mp3.getFrequency() ) {
            case 11025:
                o.playbackRate = o.streamRate = Sound.RATE_11;
                break;
            case 22050:
                o.playbackRate = o.streamRate = Sound.RATE_22;
                break;
            case 44100:
                o.playbackRate = o.streamRate = Sound.RATE_44;
                break;
        }

        o.isPlayback16bit = o.isStream16bit = true;

        o.isPlaybackStereo = o.isStreamStereo = mp3.getStereo();

        // This can only be set once a block has been read

        o.streamSampleCount = idealSamplesPerBlock = (int)(mp3.getFrequency()/frameRate);

        return o;
    }

    /** Get the next StreamSoundBlock for this sound */

    public SoundStreamBlock getNextSoundStreamBlock() throws IOException, IVException {
        byte[] buffer;
        int sampleCount = 0;

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        // Increment the blocks completed upfront, so the division in the
        // while loop works nicely.

        blocksCompleted++;

        // Add frames to the ouput buffer while the average samples per block
        // completed does not exceed the ideal.

        while( (samplesCompleted/blocksCompleted)<idealSamplesPerBlock ) {
            // Get the next frame ( unless one is already cached )

            if( firstFrameCache == null ) {
                buffer = mp3.nextFrame();
            } else {
                buffer = firstFrameCache;

                firstFrameCache = null;
            }

            // Finished if no more sound frames

            if( buffer == null ) {
                return null;
            }

            // Write the frame to the output buffer

            out.write(buffer, 0, buffer.length);

            samplesCompleted += mp3.getSamplesPerFrame();
            sampleCount += mp3.getSamplesPerFrame();
        }


        // If all has gone well, build the new block and return it.
        // This may be a zero length block (e.g. for high swf framerate with low mp3 frequency)

        MP3SoundStreamBlock o = new MP3SoundStreamBlock();

        o.sampleCount = sampleCount;
        o.delaySeek = 0;

        o.data = new DataMarker(out.toByteArray(), 0, out.size());

        return o;
    }

    /**
     * Return data size
     */
    public int getSize() {
        return dataSize;
    }

}
