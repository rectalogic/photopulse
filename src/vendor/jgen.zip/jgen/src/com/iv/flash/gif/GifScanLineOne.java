package com.iv.flash.gif;

/**
 * This class handles one-bit, packed data for one line of a gif bitmap.
 * As such it is useful for bichromal images (images of only two colors).
 * They are stored from high-bit to low-bit in each byte.
 *
 * @author Andrew Watson (Datatask Pty. Ltd.)
 */
class GifScanLineOne
        extends GifScanLine {

    /**
     * Constuctor with the pixel width specified
     *
     * @param width The number of pixel values that define the width of this line.
     */
    GifScanLineOne( int width ) {
        d_width = width;
        int size = width >> 3;
        if( (width&0x07)>0 )
            ++size;
        d_data = new byte[size];
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you want.
     * @return The integer value of the pixel requested.
     */
    int get( int index ) {
        int bindex = index >> 3;
        switch( index&0x07 ) {
            case 0:
                return Gif.unsignedByte(d_data[bindex]) >> 7;
            case 1:
                return (Gif.unsignedByte(d_data[bindex]) >> 6)&0x01;
            case 2:
                return (Gif.unsignedByte(d_data[bindex]) >> 5)&0x01;
            case 3:
                return (Gif.unsignedByte(d_data[bindex]) >> 4)&0x01;
            case 4:
                return (Gif.unsignedByte(d_data[bindex]) >> 3)&0x01;
            case 5:
                return (Gif.unsignedByte(d_data[bindex]) >> 2)&0x01;
            case 6:
                return (Gif.unsignedByte(d_data[bindex]) >> 1)&0x01;
            case 7:
                return Gif.unsignedByte(d_data[bindex])&0x01;
        }
        return 0;
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you wish to set.
     * @param value The value you wish to set the specified pixel to.
     */
    void set( int index, int value ) {
        int bindex = index >> 1;
        switch( index&0x01 ) {
            case 0:
                d_data[bindex] |= (byte) 0x7F; // Clear the bits
                d_data[bindex] |= (byte) (value << 7);
                break;
            case 1:
                d_data[bindex] |= (byte) 0xBF;
                d_data[bindex] |= (byte) ((value << 6)&0x40);
                break;
            case 2:
                d_data[bindex] |= (byte) 0xDF;
                d_data[bindex] |= (byte) ((value << 5)&0x20);
                break;
            case 3:
                d_data[bindex] |= (byte) 0xEF;
                d_data[bindex] |= (byte) ((value << 4)&0x10);
                break;
            case 4:
                d_data[bindex] |= (byte) 0xF7;
                d_data[bindex] |= (byte) ((value << 3)&0x08);
                break;
            case 5:
                d_data[bindex] |= (byte) 0xFB;
                d_data[bindex] |= (byte) ((value << 2)&0x04);
                break;
            case 6:
                d_data[bindex] |= (byte) 0xFD;
                d_data[bindex] |= (byte) ((value << 1)&0x02);
                break;
            case 7:
                d_data[bindex] |= (byte) 0xFE;
                d_data[bindex] |= (byte) (value&0x01);
                break;
        }
    }
}

;
