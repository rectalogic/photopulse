package com.iv.flash.gif;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

public class GifTableBasedImage
extends GifGraphicBlock
{
  GifTableBasedImage()
  {
  }

  int blockLabel()
  {
    return Gif.IMAGE_DESCRIPTOR;
  }

  // <Table-Based Image> ::= Image Descriptor [Local Color Table] Image Data
  public void read(InputStream ins) 
  throws IOException, GifException 
  {
    readImageDescriptor(ins);    
 
    if (d_has_local_color_table)
      readLocalColorTable(ins);    

    readImageData(ins);
  }

  public void write(OutputStream outs) 
  throws IOException, GifException 
  {
    throw new GifException("Not implemented Yet");
  }
  
  private void readImageDescriptor(InputStream ins) 
  throws IOException, GifException 
  {
    if(ins.read(d_buf, 0, 10) != 10)
      throw new GifException("Incorrect block size.");

    if (Gif.unsignedByte(d_buf[0]) != Gif.IMAGE_DESCRIPTOR)
      throw new GifException("Reading Image Descriptor in error.");

    d_image_left_position = Gif.unsignedShort(d_buf[1], d_buf[2]);
    d_image_top_position = Gif.unsignedShort(d_buf[3], d_buf[4]);
    d_image_width = Gif.unsignedShort(d_buf[5], d_buf[6]);
    d_image_height = Gif.unsignedShort(d_buf[7], d_buf[8]);

    d_has_local_color_table = ((d_buf[9] & 0x80) != 0);
    d_is_interlaced = ((d_buf[9] & 0x40) != 0);
    if (d_has_local_color_table)
    {
      d_sorted_local_color_table = ((d_buf[9] & 0x20) != 0);
      d_size_local_color_table = 1 << (((int)d_buf[9] & 0x07) + 1);
    }
    else
    {
      d_sorted_local_color_table = false;
      d_size_local_color_table = 0;
    }
  }
  
  private void readLocalColorTable(InputStream ins) 
  throws IOException, GifException 
  {
    if (!d_has_local_color_table)
      throw new GifException("Trying to read a non existant color table");

    d_local_palette = new GifPalette(d_size_local_color_table);
    d_local_palette.readData(ins);
  }

  private void readImageData(InputStream ins)
  throws IOException, GifException 
  {
    // initialise the data storage
    d_data = new GifScanLine[d_image_height];
    for (int i=0; i<d_image_height; ++i)
      d_data[i] = GifScanLine.newLine(d_image_width, 8);

    // reset the positional information
    d_xpos = 0;
    d_ypos = 0;
    d_interlace_pass = 0;
    d_interlace_increment = 8;
    d_scan_line = d_data[d_ypos];

    int min_code_size = Gif.unsignedByte(ins);
    GifLZWExtractor code_extractor = new GifLZWExtractor(ins, min_code_size);

    CodeString code_string = null;
    
    while ((code_string = code_extractor.readNextString()) != null)
      appendCodeString(code_string);
  }

  private void appendCodeString(CodeString code_string)
  throws GifException 
  {
    for (int i = 0; i<code_string.size(); ++i)
    {
      if (d_xpos >= d_image_width)
      {
	d_xpos = 0;
	// TODO - Need to check this interlaced code as it hasn't been used yet
	if (d_is_interlaced)
	  d_ypos += d_interlace_increment;
	else
	  ++d_ypos;

	while (d_ypos >= d_image_height)
	{
	  if (d_is_interlaced)
	  {
	    d_interlace_increment = 0x08 >> d_interlace_pass;
	    d_ypos = 0x04 >> d_interlace_pass;
	    ++d_interlace_pass;
	    if (d_interlace_increment == 0)
	      throw new GifException("Error, interlace increment is zero.");
	  }
	  else
	    throw new GifException("Error, gif buffer overrun.");
	}
	d_scan_line = d_data[d_ypos];
      }
      d_scan_line.set(d_xpos++, code_string.get(i));
    }
  }


  public int left() { return d_image_left_position; }
  public int top() { return d_image_top_position; }
  public int height() { return d_image_height; }
  public int width() { return d_image_width; }
  public boolean hasPalette() { return d_has_local_color_table; }
  public GifPalette getPalette() { return d_local_palette; }

  GifScanLine getLine(int index) { return d_data[index]; }
  
  // legend:                    (1)   if present, at most one occurrence
  //    	                (*)   zero or more occurrences
  // 	                        (+)   one or more occurrences
  //
  // Block Name                 Required   Label       Ext.   Vers.
  // Image Descriptor           Opt. (*)   0x2C (044)  no     87a (89a)
  private int 			d_image_left_position = 0;
  private int 			d_image_top_position = 0;
  private int 			d_image_width = 0;
  private int 			d_image_height = 0;
  private boolean 		d_has_local_color_table = false;
  private boolean 		d_is_interlaced = false;
  private boolean 		d_sorted_local_color_table = false;
  private int 			d_size_local_color_table = 0;

  // Block Name                 Required   Label       Ext.   Vers.
  // Local Color Table          Opt. (*)   none        no     87a
  private GifPalette 		d_local_palette = null;

  private GifScanLine[] d_data = null;	// array storage for lines of gif bitmap

  private byte[] d_buf = new byte[256];	// buffer to store a block of data
  private int d_buf_pos = 0;		// current position in the buffer
  private int d_buf_len = 0;		// how many bytes in this block

  private GifScanLine d_scan_line = null;
  private int d_xpos = 0;
  private int d_ypos = 0;
  private int d_interlace_increment = 0;
  private int d_interlace_pass = 0;
};
