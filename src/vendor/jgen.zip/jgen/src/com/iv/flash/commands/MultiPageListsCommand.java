/*
 * $Id: MultiPageListsCommand.java,v 1.9 2004/01/13 21:48:42 obsidianstudios Exp $
 *
 * ===========================================================================
 *
 * The JGenerator Software License, Version 1.0
 *
 * Copyright (c) 2000 Dmitry Skavish (skavish@usa.net). All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *    "This product includes software developed by Dmitry Skavish
 *     (skavish@usa.net, http://www.flashgap.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The name "The JGenerator" must not be used to endorse or promote
 *    products derived from this software without prior written permission.
 *    For written permission, please contact skavish@usa.net.
 *
 * 5. Products derived from this software may not be called "The JGenerator"
 *    nor may "The JGenerator" appear in their names without prior written
 *    permission of Dmitry Skavish.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL DMITRY SKAVISH OR THE OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

package com.iv.flash.commands;

import com.iv.flash.api.*;
import com.iv.flash.api.action.Program;
import com.iv.flash.api.button.ActionCondition;
import com.iv.flash.api.button.Button2;
import com.iv.flash.api.button.ButtonRecord;
import com.iv.flash.api.shape.FillStyle;
import com.iv.flash.api.shape.LineStyle;
import com.iv.flash.api.shape.Shape;
import com.iv.flash.api.text.Font;
import com.iv.flash.api.text.FontDef;
import com.iv.flash.api.text.Text;
import com.iv.flash.api.text.TextItem;
import com.iv.flash.commands.GenericCommand;
import com.iv.flash.context.Context;
import com.iv.flash.context.ContextFactory;
import com.iv.flash.servlet.GeneratorServletContext;
import com.iv.flash.util.GeomHelper;
import com.iv.flash.util.IVException;
import com.iv.flash.util.Log;
import com.iv.flash.util.PropertyManager;
import com.iv.flash.util.UrlDataSource;
import com.iv.flash.util.Util;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.http.HttpServletRequest;

/** MultiPage Lists JGenerator Object
 * @author  William L. Thomson Jr.
 * @company Obsidian-Studios Inc.
 */

public class MultiPageListsCommand extends GenericCommand {
    
    protected AlphaColor                            font_color;
    protected boolean                               top,url_mask;
    protected int                                   clip_column,url_column,window_column,font_size,items_per_page,num_of_nums,padding = -1;
    protected Script                                prev_symbol,next_symbol = null;
    protected String                                data_source,prev_symbol_name,next_symbol_name,instance_name,font_file,window;
    protected StringBuffer                          vars;
    
    protected void initColumnIndexes(String[][] data) {
        clip_column = findColumn("Clip",data);
        url_column = findColumn("Url",data);
        window_column = findColumn("Window",data);
        if(clip_column==-1) Log.error("MultiPageListsCommand Error\nA clip column was not specified in the data source.");
        if(url_column!=-1&&window_column==-1) Log.warn("MultiPageListsCommand Warning\nA url was specified but a window column was not specified in the data source. Default window, _blank, will be used");
    }
    protected void initParams(Context context) {
        data_source = getParameter(context,"data_source","");
        font_file = getParameter(context,"font_file","Arial.fft");
        font_size = getIntParameter(context,"font_size",12)*20;
        font_color = getColorParameter(context,"font_color",AlphaColor.blue);
        instance_name = getParameter(context,"instance_name","");
        items_per_page = getIntParameter(context,"items_per_page",0);
        next_symbol_name = getParameter(context,"next_symbol","");
        num_of_nums = getIntParameter(context,"num_of_nums",10);
        prev_symbol_name = getParameter(context,"prev_symbol","");
        padding = getIntParameter(context,"padding",2)*20;
        top = getBoolParameter(context,"top",false);
        url_mask = getBoolParameter(context,"url_mask",false);
        window = getParameter(context,"window","_blank");
        if(data_source.equals("")) Log.error("MultiPageListsCommand Error\nA data source was not specified in authoring environment.");
    }
    protected void initSymbols(FlashFile flash_file) {
        if(!prev_symbol_name.equals("")) prev_symbol = flash_file.getScript(prev_symbol_name);
        if(!next_symbol_name.equals("")) next_symbol = flash_file.getScript(next_symbol_name);
    }
    public void doCommand(FlashFile flash_file,Context context,Script parentScript,int frames) {
        initParams(context);
        initSymbols(flash_file);
        String[][] data = null;
        try {
            UrlDataSource urlDataSource = new UrlDataSource(data_source,flash_file);
            data = urlDataSource.getData();
        } catch(IVException ive) {
            Log.error("MultiPageListsCommand Error\nCould not Parse the datasource into a multi-dimensional array because :\n"+ive);
        } catch(IOException ioe) {
            Log.error("MultiPageListsCommand Error\nCould not Parse the datasource into a multi-dimensional array because :\n"+ioe);
        }
        if(data==null) Log.error("MultiPageListsCommand Error\nThe datasource it empty.");
        else {
            initColumnIndexes(data);
            makeList(flash_file,context,data);        // make the lists
        }
    }
    protected void makeList(FlashFile flash_file,Context context,String[][] data) {
        Instance instance = getInstance();                                      // get an instance of the template
        instance.name = instance_name;                                          // set the name of the instance
        double width = instance.matrix.getScaleX()*2048;                        // determine the bounding box width
        double height = instance.matrix.getScaleY()*2048;                       // determine the bounding box height
        GeomHelper.deScaleMatrix(instance.matrix);                              // scale the instance, otherwise every clip will be distorted
        Script script = instance.copyScript();
        Frame frame = script.getFrameAt(0);
        frame.addStopAction();
        Button2	prev_button = null;
        if(prev_symbol==null) prev_button = createButton(createNav("<< Prev"));
        else prev_button  = createButton(prev_symbol);
        double prev_height = prev_button.getBounds().getHeight();
        Button2	next_button = null;
        if(next_symbol==null) next_button = createButton(createNav("Next >>"));
        else next_button = createButton(next_symbol);
        double next_height = next_button.getBounds().getHeight();
        double symbol_height = (prev_height>next_height) ? prev_height:next_height;
        double y;
        double nav_y;
        if(top) {
            y = -height/2+symbol_height;
            nav_y = -height/2;
        } else {
            y = -height/2;
            nav_y = height/2-symbol_height;
        }
        double x = -width/2;
        double clip_height = 0;
        double cur_page_height = 0;                                             // this will be a cumlative total of clip heights on a page
        double page_height = height-symbol_height;                              // this will be used to determine the total height we have on a page to work with
        int start = 1;
        int stop = 1;
        int data_length = data.length-1;
        GeneratorServletContext gs_context = GeneratorServletContext.getContext();
        HttpServletRequest request = gs_context.getHttpServletRequest();
        vars = new StringBuffer();
        Enumeration enumeration = request.getParameterNames();
        while(enumeration.hasMoreElements()) {
            String param_name = enumeration.nextElement().toString();
            if(param_name.equals("st")) start = Integer.parseInt(request.getParameter("st"));
            else if(param_name.equals("sp")) stop = Integer.parseInt(request.getParameter("sp"));
            else vars.append(param_name+"="+request.getParameter(param_name)+"&");
        }
        if(start<1) {
            start = 1;
            stop = 1;
        }
        boolean stop_unknown = false;
        if(stop==1&&items_per_page!=0) stop = start+items_per_page-1;             // if we are just starting out, check it items_per_page was specified
        else if(stop==1) stop_unknown = true;
        else if(stop!=1) items_per_page = stop-start+1;
        if(stop>data_length) stop = data_length;
        for(int row=start;row<=data_length;row++) {
            Script clip_script = flash_file.getScript(data[row][clip_column]).copyScript();        // get a copy of the clip script
            Context clip_context = null;
            try {
                clip_context = ContextFactory.createContext(data,row);          // create a new context
            } catch(IVException ive) {
                Log.error("MultiPageListsCommand Error\nCould not create a clip context :\n"+ive);
            }
            try {
                flash_file.processScript(clip_script,clip_context);
            } catch(IVException ive) {
                Log.error("MultiPageListsCommand Error\nCould not process clip script and context :\n"+ive);
            }
            clip_height = clip_script.getBounds().getHeight();                  // get the height before creating and adding a sub menu
            cur_page_height += clip_height;                                     // add the clip height to our current page's height
            if(cur_page_height<page_height) {                                   // check to see if there is still room on the page                
                if(stop_unknown) {
                    stop = row;
                    items_per_page++;
                }
                if(row<=stop) {
                    if(url_mask) {
                        Button2 button2 = createButton(data,row,clip_script);
                        frame.addInstance(button2,1,AffineTransform.getTranslateInstance(x,y),null);
                    } else {
                        frame.addInstance(clip_script,1,AffineTransform.getTranslateInstance(x,y),null);
                    }
                    y += clip_height;
                }
            } else break;
        }
        Script nav_script = new Script(1);
        Frame nav_frame = nav_script.getFrameAt(0);
        int num_of_pages = Math.round((float)data_length/(float)items_per_page);
        if(num_of_pages<num_of_nums) num_of_nums = num_of_pages;                                                // limit the amount of page numbers due to lack of pages
        int page = Math.round((float)stop/(float)items_per_page);
        frame.addInstance(createText(page+" of "+num_of_pages+" page(s)",AlphaColor.black),1,AffineTransform.getTranslateInstance(x,nav_y),null);
        Text t = createText(data_length+" item(s)",AlphaColor.black);
        frame.addInstance(t,1,AffineTransform.getTranslateInstance(((width/2)-t.getBounds().getWidth()),nav_y),null);
        if(page>1) {
            if(stop>=data_length) prev_button.addActionCondition(onRelease(request,start-items_per_page,start-1));
            else prev_button.addActionCondition(onRelease(request,start-items_per_page,stop-items_per_page));
            nav_frame.addInstance(prev_button,1,AffineTransform.getTranslateInstance(x,0),null);
            x += prev_button.getBounds().getWidth()+(padding*2);
        }
        if(stop<data_length) next_button.addActionCondition(onRelease(request,start+items_per_page,stop+items_per_page));
        int nav_page = 1;
        if(page>num_of_nums) nav_page = (page/num_of_nums)*num_of_nums;
        stop = nav_page*items_per_page;
        start = stop-items_per_page+1;
        for(int p=1;p<=num_of_nums&&nav_page<=num_of_pages;p++) {
            if(page==nav_page) {
                Text text = createText(""+nav_page,AlphaColor.black);
                nav_frame.addInstance(text,1,AffineTransform.getTranslateInstance(x,0),null);
                x += text.getBounds().getWidth()+padding;
            } else {
                Button2 button2 = createButton(createNav(""+nav_page));
                button2.addActionCondition(onRelease(request,start,stop));
                nav_frame.addInstance(button2,1,AffineTransform.getTranslateInstance(x,0),null);
                x += button2.getBounds().getWidth()+padding;
            }
            start += items_per_page;
            stop += items_per_page;
            nav_page++;
        }
        x += padding;
        if(page<num_of_pages) nav_frame.addInstance(next_button,1,AffineTransform.getTranslateInstance(x,0),null);
        frame.addInstance(nav_script,1,AffineTransform.getTranslateInstance((width-nav_script.getBounds().getWidth())/2,nav_y),null);
    }
    protected Button2 createButton(FlashDef flash_def) {
        Button2 button2 = new Button2();
        int states = ButtonRecord.Up|ButtonRecord.Over|ButtonRecord.Down;                           // add the symbol to define the rest of the states
        button2.addButtonRecord(new ButtonRecord(states,flash_def,1,AffineTransform.getTranslateInstance(0,0),CXForm.newIdentity(true)));
        Shape shape = new Shape();
        shape.setBounds(flash_def.getBounds());
        shape.setFillStyle0(FillStyle.newSolid(new Color(0,0,0)));
        shape.drawRectangle(flash_def.getBounds());
        button2.addButtonRecord(new ButtonRecord(ButtonRecord.HitTest,shape,2,AffineTransform.getTranslateInstance(0,0),CXForm.newIdentity(true)));
        button2.setTrackAs(Button2.TrackAsButton);
        return(button2);
    }
    protected Button2 createButton(String[][] data,int row,Script clip_script) {
        Button2 button2 = createButton(clip_script);
        Program program = new Program();
        if(window_column==-1) program.getURL(data[row][url_column],"_blank");
        else program.getURL(data[row][url_column],data[row][window_column]);
        button2.addActionCondition(ActionCondition.onPress(program));
        return(button2);
    }
    protected FlashDef createNav(String text) {
        Text t = createText(text);
        return(addUnderline(t,t.getBounds().getWidth(),t.getBounds().getHeight()));
    }
    protected Text createText(String text) {
        return(createText(text,font_color));
    }
    protected Text createText(String text,AlphaColor alpha_color) {
        String fft_file = Util.translatePath(font_file);
        File file = new File(fft_file);
        if(!file.exists()) {
            fft_file = Util.concatFileNames(PropertyManager.fontPath,fft_file);
            file = new File(Util.getInstallDir(),fft_file);
        }
        fft_file = file.getAbsolutePath();
        Font font = FontDef.load(fft_file);
        double ratio = 1024/(double)font_size;
        char[] chars = text.toCharArray();
        double em_width = 0;
        for(int i=0;i<chars.length;i++) {
            int index = font.getIndex(chars[i]);
            em_width += font.getAdvanceValue(index);
        }
        double font_height = (font.ascent+font.descent)/ratio;
        double font_width = em_width/ratio;
        Text t = Text.newText();
        t.setBounds(GeomHelper.newRectangle(0,0,font_width,font_height));
        TextItem text_item = new TextItem(text,font,font_size,alpha_color);
        text_item.style = Text.JG_STYLE;
        t.addTextItem(text_item);
        return(t);
    }
    protected FlashDef addUnderline(Text text,double font_width,double font_height) {
        Rectangle2D rect = GeomHelper.newRectangle(0,0,font_width,5);
        Shape shape = new Shape();
        shape.setBounds(rect.getBounds());
        shape.setLineStyle(new LineStyle(10,font_color));
        shape.drawLine(0,0,(int)font_width,0);
        Script script = new Script(1);
        Frame frame = script.getFrameAt(0);
        frame.addInstance(text,1,AffineTransform.getTranslateInstance(0,0),null);
        frame.addInstance(shape,1,AffineTransform.getTranslateInstance(0,font_height-10),null);
        return(script);
    }
    protected ActionCondition onRelease(HttpServletRequest request,int start,int stop) {
        Program program = new Program();
	StringBuffer sb = new StringBuffer();
	sb.append(request.getRequestURI()).append("?");
        if(vars.length()>0) sb.append(vars.toString());
        sb.append("st=").append(start).append("&sp=").append(stop).append("&");
	program.push(sb.toString());
        program.push(window);
        program.getURL(0);
        return(ActionCondition.onRelease(program));
    }
}
