package com.iv.flash.gif;

public class GifException extends Exception {

    public GifException( String msg ) {
        super(msg);
    }
}
