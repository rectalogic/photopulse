package com.iv.flash.gif;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class GifLogicalScreen
        implements GifIO {
    public GifLogicalScreen() {
    }

    // <Logical Screen> ::= Logical Screen Descriptor [Global Color Table]
    public void read( InputStream ins )
            throws IOException, GifException {
        readLogicalScreenDescriptor(ins);

        if (d_has_global_color_table)
            readGlobalColorTable(ins);
    }

    private void readLogicalScreenDescriptor( InputStream ins )
            throws IOException, GifException {
        if (ins.read(d_buf, 0, 7) != 7) {
            throw new GifException(
                    "Not enough bytes available for screen descriptor.");
        }

        d_logical_screen_width = Gif.unsignedShort(d_buf[0], d_buf[1]);
        d_locical_screen_height = Gif.unsignedShort(d_buf[2], d_buf[3]);

        d_has_global_color_table = (((int) d_buf[4]&0x80) != 0);
        if (d_has_global_color_table) {
            d_color_resolution = (((int) d_buf[4] >> 4)&0x07 + 1);
            d_sorted_global_color_table = (((int) d_buf[4]&0x08) != 0);
            d_size_global_color_table = (1 << (((int) d_buf[4]&0x07) + 1));
        } else {
            d_color_resolution = 8;
            d_sorted_global_color_table = false;
            d_size_global_color_table = 0;
        }

        d_background_color_index = Gif.unsignedByte(d_buf[5]);
        d_pixel_aspect_ratio = Gif.unsignedByte(d_buf[6]);
    }

    private void readGlobalColorTable( InputStream ins )
            throws IOException, GifException {
        if (!d_has_global_color_table)
            throw new GifException("Trying to read a non existant color table");

        d_global_palette = new GifPalette(d_size_global_color_table);
        d_global_palette.readData(ins);
    }

    public void write( OutputStream outs )
            throws IOException, GifException {
        throw new GifException("Not implemented Yet");
    }

    public int width() {
        return d_logical_screen_width;
    }

    public int height() {
        return d_locical_screen_height;
    }

    public boolean hasPalette() {
        return d_has_global_color_table;
    }

    public GifPalette getPalette() {
        return d_global_palette;
    }

    public int backgroundIndex() {
        return d_background_color_index;
    }

    // legend:                    (1)   if present, at most one occurrence
    //    	                (*)   zero or more occurrences
    // 	                        (+)   one or more occurrences
    //
    // Block Name                 Required   Label       Ext.   Vers.
    // Logical Screen Descriptor  Req. (1)   none        no     87a (89a)
    private int d_logical_screen_width = 0;
    private int d_locical_screen_height = 0;
    private boolean d_has_global_color_table = false;
    private int d_color_resolution = 0;
//  private int			d_color_resolution_override = 0;
    private boolean d_sorted_global_color_table = false;
    private int d_size_global_color_table = 0;
    private int d_background_color_index = 0;
    private int d_pixel_aspect_ratio = 0;

    // Block Name                 Required   Label       Ext.   Vers.
    // Global Color Table         Opt. (1)   none        no     87a
    private GifPalette d_global_palette = null;

    private byte[] d_buf = new byte[16];
}

;
