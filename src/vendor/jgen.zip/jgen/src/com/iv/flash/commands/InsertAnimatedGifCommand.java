/*
* $Id: InsertAnimatedGifCommand.java,v 1.5 2003/05/21 14:13:51 skavish Exp $
*
* ===========================================================================
*
* The JGenerator Software License, Version 1.0
*
* Copyright (c) 2000 Dmitry Skavish (skavish@usa.net). All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright
*    notice, this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright
*    notice, this list of conditions and the following disclaimer in
*    the documentation and/or other materials provided with the
*    distribution.
*
* 3. The end-user documentation included with the redistribution, if
*    any, must include the following acknowlegement:
*    "This product includes software developed by Dmitry Skavish
*     (skavish@usa.net, http://www.flashgap.com/)."
*    Alternately, this acknowlegement may appear in the software itself,
*    if and wherever such third-party acknowlegements normally appear.
*
* 4. The name "The JGenerator" must not be used to endorse or promote
*    products derived from this software without prior written permission.
*    For written permission, please contact skavish@usa.net.
*
* 5. Products derived from this software may not be called "The JGenerator"
*    nor may "The JGenerator" appear in their names without prior written
*    permission of Dmitry Skavish.
*
* THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
* WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED.  IN NO EVENT SHALL DMITRY SKAVISH OR THE OTHER
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
* OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
* SUCH DAMAGE.
*
*/

package com.iv.flash.commands;

import com.iv.flash.api.FlashFile;
import com.iv.flash.api.Frame;
import com.iv.flash.api.Instance;
import com.iv.flash.api.Script;
import com.iv.flash.api.image.LLBitmap;
import com.iv.flash.api.shape.FillStyle;
import com.iv.flash.api.shape.Shape;
import com.iv.flash.context.Context;
import com.iv.flash.gif.*;
import com.iv.flash.url.IVUrl;
import com.iv.flash.util.*;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.InputStream;
import java.util.Stack;

public class InsertAnimatedGifCommand extends GenericCommand {

    public InsertAnimatedGifCommand() {
    }

    public void doCommand( FlashFile file, Context context, Script parent, int frameNum ) throws IVException {
        // Get the command instance
        Instance inst = getInstance();

        // Get the name of the image being inserted.
        String gif_file_name = getParameter(context, "name", "");
        boolean scaleToFit = getBoolParameter(context, "scale", false);
        boolean expand = getBoolParameter(context, "expand", true);
        String instancename = getParameter(context, "instancename");

        // Add the media file to the flash file resources
        FlashFile flashFile = null;
        try {
            flashFile = addExternalMedia(file, gif_file_name);
        } catch (Exception e) {
            throw new IVException(Resource.ERRCMDFILEREAD, new Object[]{gif_file_name, getCommandName()}, e);
        }

        Script script = null;
        // insert flash movie
        synchronized (flashFile) {
            script = flashFile.getMainScript();
            script.resetMain();
        }

        inst.setScript(script);

        Rectangle2D r = script.getBounds();
        double width = r.getWidth();
        double height = r.getHeight();

        double scaleX, scaleY, translateX, translateY;
        if (scaleToFit) {
            scaleX = 2048.0/width;
            scaleY = 2048.0/height;
//            translateX = -(scaleX*width)/2;
//            translateY = -(scaleY*height)/2;
        } else {
            scaleX = 1.0;
            scaleY = 1.0;
        }
        translateX = -1024;
        translateY = -1024;

        // M = S * T, where S: scale matrix, T: translation matrix (-w/2, -h/2)
        //inst.matrix.concatenate(new AffineTransform(scaleX, 0, 0, scaleY, 0, 0));
        inst.matrix.concatenate(new AffineTransform(scaleX, 0, 0, scaleY, translateX, translateY));

        if (instancename!=null) {
            inst.name = instancename;
        }

        // expand frames
        if (expand) {
            // create new frames if needed
            int myTotal = script.getFrameCount();
            parent.getFrameAt(frameNum + myTotal - 1);
        }

    }

    FlashFile createSwfFromGif( FlashFile file, String file_name, FlashBuffer fbuf ) throws IVException, IOException, GifException {
        file_name = Util.translatePath(file_name);
        int index = file_name.lastIndexOf(Util.fileSeparator);
        String dir = "";
        if (index>=0) {
            dir = file_name.substring(0, index);
            file_name = file_name.substring(index + 1);
        }

        // Read the image file
        GifImage gif_image = new GifImage();
        gif_image.read(fbuf.getInputStream());

        // Get the images
        GifTableBasedImage[] images = gif_image.getAllImages();

        // Setup the swf (flash file) to hold them
        FlashFile swf = new FlashFile();
        swf.setFileName(file_name);
        swf.setFileDir(dir);
        swf.setFullParsing(false);
        swf.setEncoding(PropertyManager.defaultEncoding);

        // Copy frame rate and version
        swf.setFrameRate(file.getFrameRate());
        swf.setVersion(file.getVersion());
        swf.setFileSize(100);

        // Create the script
        Script scr = new Script(-1, 1);

        int depth = 0;
        // Draw the background shape (if available)
        GifLogicalScreen screen = gif_image.getLogicalScreen();
        if (false) {
        //if (screen.hasPalette()) {
            GifPalette palette = screen.getPalette();
            // Draw shape with background
            Shape shape = new Shape();
            // Set color fill
            shape.setFillStyle1(FillStyle.newSolid(palette.get(screen.backgroundIndex())));
            Rectangle2D rect = GeomHelper.newRectangle(0, 0, screen.width(), screen.height());
            shape.drawRectangle(rect);
            shape.setBounds(rect);

            // This instance is what will be added to the movie
            Instance inst = new Instance();
            inst.def = shape;
            inst.matrix = null;

            // Place the new bitmap on the frame
            Frame s_frame = scr.getFrameAt(0);
            s_frame.addInstance(inst, depth++);
        }

        Stack depth_list = new Stack();

        int frame_no = 0;
        int total_delay = 0;
        int frame_rate = (file.getFrameRate()>>8);
        int disposal_method = GifGraphicControlExtension.DISPOSAL_METHOD_NONE;
        GifConverter gh = new GifConverter();
        for (int i = 0; i<images.length; ++i) {
            GifTableBasedImage img = images[i];
            GifPalette palette = gif_image.getPaletteFor(img);
            GifGraphicControlExtension ctl_ext = img.controlExtension();

            // Create a LLBitmap for each table image
            LLBitmap bitmap = new LLBitmap();
            bitmap.setDimensions(img.width(), img.height());
            bitmap.setFormat(3); // GIF image are always 8 bits
            // but can have transparency
            bitmap.setAlpha((ctl_ext==null)? false: ctl_ext.hasTransparency());
            bitmap.setColorTableSize(palette.size() - 1);
            bitmap.setZLibData(GifConverter.getZlibData(palette, img));

            // Add the bitmap to the swf (FlashFile)
            swf.addDef(bitmap);

            // Translate by -1/2 pixel (10 twips) to avoid Flash rendering
            // with top/left pixels duplicated and bottom right pixels truncated.
            int xoff = img.left()*20;
            int yoff = img.top()*20;
            AffineTransform fill_m = AffineTransform.getTranslateInstance(xoff - 10, yoff - 10);
            Rectangle2D rect = GeomHelper.newRectangle(xoff, yoff, img.width()*20, img.height()*20);

            // Scale from twips to pixels
            fill_m.scale(20, 20);

            // Draw shape with bitmap
            Shape shape = new Shape();
            // Set bitmap fill
            shape.setFillStyle0(0);
            shape.setFillStyle1(FillStyle.newClippedBitmap(bitmap, fill_m));
            shape.drawRectangle(rect);
            shape.setBounds(rect);

            // This instance is what will be added to the movie
            Instance inst = new Instance();
            inst.def = shape;
            inst.matrix = null;

            Frame s_frame = scr.getFrameAt(frame_no);

            // Remove the old bitmap(s) from the frame ?
            switch (disposal_method) {
                case GifGraphicControlExtension.DISPOSAL_METHOD_BACKGROUND_RESTORE:
                    // remove all pictures
                    while (!depth_list.empty()) {
                        Integer dlv = (Integer) depth_list.pop();
                        s_frame.removeInstance(dlv.intValue());
                    }
                    break;
                case GifGraphicControlExtension.DISPOSAL_METHOD_USE_PREVIOUS:
                    {
                        // remove last picture only
                        Integer dlv = (Integer) depth_list.pop();
                        s_frame.removeInstance(dlv.intValue());
                    }
                    break;
                case GifGraphicControlExtension.DISPOSAL_METHOD_NONE:
                case GifGraphicControlExtension.DISPOSAL_METHOD_LEAVE_IN_PLACE:
                default:
                    // do nothing
                    break;
            }

            // Place the new bitmap on the frame
            depth_list.push(new Integer(depth));
            s_frame.addInstance(inst, depth++);

            // work out the number of frames between images.
            if (ctl_ext!=null) {
                total_delay += (ctl_ext.delayTime()*frame_rate);
                disposal_method = ctl_ext.disposalMethod();
            } else {
                total_delay += 100;
            }
            int fn = total_delay/100;
            if (fn==frame_no) {
                ++frame_no;
                total_delay = frame_no*100;
            } else {
                frame_no = fn;
            }
        }
        // Get the last frame (just in case the last image is displayed for more
        // than one frame.
        Frame s_frame = scr.getFrameAt(frame_no - 1);

        // Set the script to the swf (flash file)
        swf.setMainScript(scr);

        return swf;
    }

    /**
     * Reads an external media and adds it to this file (if it is not here yet)
     * and to media cache
     *
     * @param fileName name of the file to be added
     * @return FlashFile or Bitmap
     * @exception IVException
     */
    FlashFile addExternalMedia( FlashFile file, String file_name ) throws IVException, IOException, GifException {
        // try to retrieve from the file's cache
        Object media = file.getExternalMedia(file_name);
        if (media!=null && (media instanceof FlashFile))
            return (FlashFile) media;

        // read the media
        IVUrl url = IVUrl.newUrl(file_name, file);
        InputStream is = url.getInputStream();
        FlashBuffer fb = new FlashBuffer(is);

        // detect media type
        FlashFile media_file = createSwfFromGif(file, file_name, fb);

        // add to this file's cache
        file.addExternalMedia(file_name, media_file);

        return media_file;
    }
}

;
