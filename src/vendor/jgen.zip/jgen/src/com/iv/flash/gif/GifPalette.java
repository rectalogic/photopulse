package com.iv.flash.gif;

import com.iv.flash.api.Color;

import java.io.*;

/**
 * Stores the colors, used in a gif image.
 *
 * @author Andrew Watson (Datatask Pty. Ltd.)
 */
public class GifPalette {

    /**
     * Constructs GifPalette with a specified size.
     *
     * @param size The size of the palette to create.  (max 256)
     */
    public GifPalette( int size ) {
        if( size>256 )
            size = 256;

        d_palette = new Color[size];
    }

    /**
     * Constuctor that copies the given palette
     *
     * @param rhs The palette to copy.
     */
    public GifPalette( GifPalette rhs ) {
        copy(rhs);
    }

    /**
     * Assignment operator.
     *
     * @param rhs The palette to copy.
     */
    public void copy( GifPalette rhs ) {
        d_palette = (Color[]) rhs.d_palette.clone();
    }

    public static GifPalette getDefault() {
        GifPalette pal = new GifPalette(256);
        // Set the EGA colors
        pal.set(0, new Color(0, 0, 0));
        pal.set(1, new Color(0, 0, 128));
        pal.set(2, new Color(0, 128, 0));
        pal.set(3, new Color(0, 128, 128));
        pal.set(4, new Color(128, 0, 0));
        pal.set(5, new Color(128, 0, 128));
        pal.set(6, new Color(128, 128, 0));
        pal.set(7, new Color(200, 200, 200));
        pal.set(8, new Color(100, 100, 100));
        pal.set(9, new Color(100, 100, 255));
        pal.set(10, new Color(100, 255, 100));
        pal.set(11, new Color(100, 255, 255));
        pal.set(12, new Color(255, 100, 100));
        pal.set(13, new Color(255, 100, 255));
        pal.set(14, new Color(255, 255, 100));
        pal.set(15, new Color(255, 255, 255));

        // Add the 216 colors of the Netscape Palette.
        int index = 16;
        for( int g = 0x00; g<=0xFF; g += 0x33 ) {
            for( int b = 0x00; b<=0xFF; b += 0x33 ) {
                for( int r = 0x00; r<=0xFF; r += 0x33 ) {
                    pal.set(index++, new Color(r, g, b));
                }
            }
        }

        // Set remaining to black
        while( index<=255 )
            pal.set(index++, new Color(0, 0, 0));

        return pal;
    }

    /**
     * Read the color data from an input stream
     *
     * @param ins The stream that contains the color data for this palette.
     * @return true if there was enough data, false otherwise.
     */
    boolean readData( InputStream ins ) {
        // read the data
        try {
            for( int i = 0; i<d_palette.length; ++i )
                d_palette[i] = new Color(ins.read(), ins.read(), ins.read());
        } catch( IOException ex ) {
            return false;
        }
        return true;
    }

    /**
     * Write the color data to an output sream.
     *
     * @param outs The streamt to write the color data for this palette to.
     * @return true if the write was successful, false otherwise.
     */
    boolean writeData( OutputStream outs )
            throws IOException {
        // Write the data
        for( int i = 0; i<d_palette.length; ++i ) {
            outs.write(d_palette[i].getRed());
            outs.write(d_palette[i].getGreen());
            outs.write(d_palette[i].getBlue());
        }
        return true;
    }

    /**
     * Get the color that is stored at the given index.
     *
     * @param index the 0 based index of the color to return.
     * @return the specified color.
     */
    public Color get( int index ) {
        return d_palette[index];
    }

    /**
     * Set the color that is stored at a given index.
     *
     * @param index the 0 based index of the color to set.
     * @param col the color to store at the given index.
     */
    public void set( int index, Color col ) {
        d_palette[index] = col;
    }

    /**
     * Get the number of colors stored in this palette
     *
     * @return the size of this palette.
     */
    public int size() {
        return d_palette.length;
    }

    private Color d_palette[];	// The array of colors we store.
}

;
