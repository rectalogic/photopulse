package com.iv.flash.gif;

import java.io.*;

class GifHeader
        implements GifIO {

    public GifHeader() {
    }

    public void read( InputStream ins )
            throws IOException, GifException {
        if( ins.read(d_signature) != 3 )
            throw new GifException("Not enough bytes available for signature.");

        if( d_signature[0] != 'G' || d_signature[1] != 'I' || d_signature[2] != 'F' ) {
            throw new GifException("Invalid signature ("
                                   + new String(d_signature) + ")");
        }

        if( ins.read(d_version) != 3 )
            throw new GifException("Not enough bytes available for version.");

        if( d_version[0] != '8' || d_version[2] != 'a' ) {
            throw new GifException("Invalid version ("
                                   + new String(d_signature) + ")");
        }

        if( d_version[1] == '7' )
            version87a(true);
        else if( d_version[1] == '9' )
            version89a(true);
        else {
            throw new GifException("Invalid version ("
                                   + new String(d_signature) + ")");
        }
    }

    public void write( OutputStream outs )
            throws IOException, GifException {
        outs.write(new String("GIF").getBytes());

        if( version87a() )
            outs.write(new String("87a").getBytes());
        else if( version89a() )
            outs.write(new String("89a").getBytes());
        else {
            throw new GifException("No version set!");
        }
    }

    boolean version87a() {
        return d_version_87a;
    }

    void version87a( boolean set ) {
        d_version_87a = set;
        d_version_89a = !set;
    }

    boolean version89a() {
        return d_version_89a;
    }

    void version89a( boolean set ) {
        d_version_87a = !set;
        d_version_89a = set;
    }

    // legend:                    (1)   if present, at most one occurrence
    //    	                (*)   zero or more occurrences
    // 	                        (+)   one or more occurrences
    //
    // Block Name                 Required   Label       Ext.   Vers.
    // Header                     Req. (1)   none        no     N/A
    private byte[] d_signature = new byte[3];
    private byte[] d_version = new byte[3];
    private boolean d_version_87a = false;
    private boolean d_version_89a = false;
}

;
