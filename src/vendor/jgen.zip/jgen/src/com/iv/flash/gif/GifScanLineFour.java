package com.iv.flash.gif;

/**
 * This class handles four-bit, packed data for one line of a gif bitmap.
 * As such it is useful for EGA images (images with up to 16 colors).
 * They are stored from high-nibble to low-nibble in each byte.
 *
 * @author Andrew Watson (Datatask Pty. Ltd.)
 */
class GifScanLineFour
        extends GifScanLine {

    /**
     * Constuctor with the pixel width specified
     *
     * @param width The number of pixel values that define the width of this line.
     */
    GifScanLineFour( int width ) {
        d_width = width;
        int size = width >> 1;
        if( (width&0x01)>0 )
            ++size;
        d_data = new byte[size];
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you want.
     * @return The integer value of the pixel requested.
     */
    int get( int index ) {
        int bindex = index >> 1;
        switch( index&0x01 ) {
            case 0:
                return Gif.unsignedByte(d_data[bindex]) >> 4;
            case 1:
                return Gif.unsignedByte(d_data[bindex])&0x0F;
        }
        return 0;
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you wish to set.
     * @param value The value you wish to set the specified pixel to.
     */
    void set( int index, int value ) {
        int bindex = index >> 1;
        switch( index&0x01 ) {
            case 0:
                d_data[bindex] |= (byte) 0x0F; // Clear the bits
                d_data[bindex] |= (byte) (value << 4);
                break;
            case 1:
                d_data[bindex] |= (byte) 0xF0;
                d_data[bindex] |= (byte) (value&0x0F);
                break;
        }
    }
}

;
