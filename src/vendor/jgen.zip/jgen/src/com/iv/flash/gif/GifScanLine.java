package com.iv.flash.gif;

/**
 * The representation of one line of a gif image, stored in a byte array.
 * This is both the base class, and recommended interface for creating and
 * using scan lines.
 *
 * @author Andrew Watson (Datatask Pty. Ltd.)
 */
abstract class GifScanLine {

    /**
     * Factory method to create a new GifScanLine for the required width and depth.
     * This method should be used as it will use the most efficient storage
     * method for the given depth.
     *
     * @param width The number of pixel values that define the width of this line.
     * @param depth The number of bits per pixel that need to be stored.
     * @return A newly created GifScanLine that can store width number of pixels.
     */
    static GifScanLine newLine( int width, int depth ) {
        switch( depth ) {
            case 8:
                return new GifScanLineEight(width);
            case 4:
                return new GifScanLineFour(width);
            case 2:
                return new GifScanLineTwo(width);
            case 1:
                return new GifScanLineOne(width);
        }
        return new GifScanLineOdd(width, depth);
    }

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you want.
     * @return The integer value of the pixel requested.
     */
    abstract int get( int index );

    /**
     * Get the value of the pixel at a given index.
     *
     * @param index The 0 based index of the pixel value you wish to set.
     * @param value The value you wish to set the specified pixel to.
     */
    abstract void set( int index, int value );

    /**
     * Get the reference to the raw data for conversion to other formats.
     * Either use the byte array returned only for reading the values or take a
     * clone copy of the data.
     *
     * @return The raw data buffer that the pixel values are stored in.
     */
    byte[] rawData() {
        return d_data;
    }

    /**
     * Get the width that this scan line was created with.
     *
     * @return The number of pixels this scan line contains.
     */
    int getWidth() {
        return d_width;
    }

    int d_width;		// The width we were created with.
    byte[] d_data;	// The data we are holding.
}

;
