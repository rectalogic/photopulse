package com.iv.flash.gif;

import java.io.*;

public class GifGraphicControlExtension
        implements GifIO {

    public GifGraphicControlExtension() {
    }

    public void read( InputStream ins )
            throws IOException, GifException {
        if( Gif.unsignedByte(ins) != Gif.GRAPHIC_CONTROL_EXTENSION )
            throw new GifException("Reading Graphic Control Extension in error.");
        if( Gif.unsignedByte(ins) != 4 )
            throw new GifException("Incorrect block size.");

        if( ins.read(d_buf, 0, 4) != 4 ) {
            throw new GifException(
                    "Not enough bytes available for Graphic Control Extension.");
        }

        d_disposal_method = (((int) d_buf[0] >> 2)&0x07);
        d_expects_user_input = (((int) d_buf[0]&0x02) != 0);
        d_has_transparent_index = (((int) d_buf[0]&0x01) != 0);

        d_delay_time = Gif.unsignedShort(d_buf[1], d_buf[2]);
        d_transparency_index = Gif.unsignedByte(d_buf[3]);

        if( ins.read() != 0 )
            throw new GifException("Incorrect data.");
    }

    public void write( OutputStream outs )
            throws IOException, GifException {
        throw new GifException("Not implemented Yet");
    }

    public int disposalMethod() {
        return d_disposal_method;
    }

    public boolean expectsUserImput() {
        return d_expects_user_input;
    }

    public boolean hasTransparency() {
        return d_has_transparent_index;
    }

    public int delayTime() {
        return d_delay_time;
    }

    public int transparencyIndex() {
        return d_transparency_index;
    }

    // legend:                    (1)   if present, at most one occurrence
    //    	                (*)   zero or more occurrences
    // 	                        (+)   one or more occurrences
    //
    // Block Name                 Required   Label       Ext.   Vers.
    // Graphic Control Extension  Opt. (*)   0xF9 (249)  yes    89a
    private int d_disposal_method = 0;
    private boolean d_expects_user_input = false;
    private boolean d_has_transparent_index = false;
    private int d_delay_time = 0;// hundredths of a second
    private int d_transparency_index = -1;

    public static final int DISPOSAL_METHOD_NONE = 0x00;
    public static final int DISPOSAL_METHOD_LEAVE_IN_PLACE = 0x01;
    public static final int DISPOSAL_METHOD_BACKGROUND_RESTORE = 0x02;
    public static final int DISPOSAL_METHOD_USE_PREVIOUS = 0x03;

    private byte[] d_buf = new byte[16];
}

;
