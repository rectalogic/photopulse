package com.iv.flash.gif;

abstract class GifGraphicBlock
        extends GifBlock {

    public GifGraphicControlExtension controlExtension() {
        return d_graphic_control_extension;
    }

    public void controlExtension( GifGraphicControlExtension extension ) {
        d_graphic_control_extension = extension;
    }

    private GifGraphicControlExtension d_graphic_control_extension = null;
}

;
