package com.iv.flash.gif;

import java.io.*;

abstract class GifBlock
        implements GifIO {

    abstract int blockLabel();

    abstract public void read( InputStream ins )
            throws IOException, GifException;

    abstract public void write( OutputStream outs )
            throws IOException, GifException;
}

;
