package com.iv.flash.gif;

class CodeString {

    CodeString() {
        d_buffer = new byte[8];
    }

    CodeString( CodeString rhs ) {
        d_buffer = (byte[]) rhs.d_buffer.clone();
        d_size = rhs.d_size;
    }

    CodeString( int size, byte val ) {
        d_buffer = new byte[8];
        checkSize(size);
        for( int i = 0; i<size; ++i )
            d_buffer[i] = val;
        d_size = size;
    }

    int size() {
        return d_size;
    }

    void clear() {
        d_size = 0;
    }

    byte front() {
        return get(0);
    }

    byte get( int pos ) {
        return d_buffer[pos];
    }

    void push_back( byte b ) {
        checkSize(d_size + 1);
        d_buffer[d_size++] = b;
    }

    void push_back( byte[] bs ) {
        checkSize(d_size + bs.length);
        System.arraycopy(bs, 0, d_buffer, d_size, bs.length);
        d_size += bs.length;
    }

    private void checkSize( int len ) {
        if( len<d_buffer.length )
            return;

        int n_length = len >> 12; // max increment is 4k
        if( n_length == 0 ) {
            n_length = d_buffer.length;
            while( n_length<len )
                n_length = n_length << 1;
        } else {
            n_length = (n_length + 1) << 12;
        }

        byte[] n_buffer = new byte[n_length];
        System.arraycopy(d_buffer, 0, n_buffer, 0, d_buffer.length);
        d_buffer = n_buffer;
    }

    private byte[] d_buffer;
    private int d_size = 0;
}

;
