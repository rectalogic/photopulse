/*
 * $Id: MP3SoundStreamBlock.java,v 1.3 2002/11/26 23:10:41 skavish Exp $
 *
 * ===========================================================================
 *
 */

package com.iv.flash.api.sound;

import com.iv.flash.api.FlashItem;
import com.iv.flash.parser.DataMarker;
import com.iv.flash.util.FlashOutput;
import com.iv.flash.util.ScriptCopier;

public class MP3SoundStreamBlock extends SoundStreamBlock {

    public int sampleCount; // MP3StreamSoundData.SampleCount

    public int delaySeek;   // MP3SoundData.DelaySeek
    public DataMarker data; // MP3SoundData.MP3Frames

    public void write( FlashOutput fob ) {
        fob.writeTag(getTag(), 2 + 2 + data.length());

        fob.writeWord(sampleCount);

        fob.writeWord(delaySeek);

        data.write(fob);
    }

    public boolean isConstant() {
        return true;
    }

    protected FlashItem copyInto( FlashItem item, ScriptCopier copier ) {
        super.copyInto(item, copier);

        ((MP3SoundStreamBlock) item).sampleCount = sampleCount;
        ((MP3SoundStreamBlock) item).delaySeek = delaySeek;

        ((MP3SoundStreamBlock) item).data = data;

        return item;
    }

    public FlashItem getCopy( ScriptCopier copier ) {
        return copyInto(new MP3SoundStreamBlock(), copier);
    }
}
