package com.iv.flash.gif;

import java.io.*;

class GifCommentExtension
        extends GifSpecialBlock {

    GifCommentExtension() {
    }

    int blockLabel() {
        return Gif.COMMENT_EXTENSION;
    }

    public void read( InputStream ins )
            throws IOException, GifException {
        if( Gif.unsignedByte(ins) != Gif.COMMENT_EXTENSION )
            throw new GifException("Reading Comment Extension block in error.");

        readDataBlocks(ins, d_comment);

        // Dmitry Skavish: This causes problems loading otherwise perfect gifs, so I just commented it out.
        //throw new GifException("Not tested Yet");
    }

    public void write( OutputStream outs )
            throws IOException, GifException {
        throw new GifException("Not implemented Yet");
    }

    // legend:                    (1)   if present, at most one occurrence
    //    	                (*)   zero or more occurrences
    // 	                        (+)   one or more occurrences
    //
    // Block Name                 Required   Label       Ext.   Vers.
    // Comment Extension          Opt. (*)   0xFE (254)  yes    89a
    private StringBuffer d_comment = new StringBuffer();
}
