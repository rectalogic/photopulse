package com.iv.flash.gif;

import java.io.*;

interface GifIO {

    void read( InputStream ins )
            throws IOException, GifException;

    void write( OutputStream outs )
            throws IOException, GifException;
}

;
