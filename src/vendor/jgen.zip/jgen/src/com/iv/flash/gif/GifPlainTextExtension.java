package com.iv.flash.gif;

import java.io.*;

class GifPlainTextExtension
        extends GifGraphicBlock {

    GifPlainTextExtension() {
    }

    int blockLabel() {
        return Gif.PLAIN_TEXT_EXTENSION;
    }

    public void read( InputStream ins )
            throws IOException, GifException {
        throw new GifException("Not implemented Yet");
    }

    public void write( OutputStream outs )
            throws IOException, GifException {
        throw new GifException("Not implemented Yet");
    }
}

;
