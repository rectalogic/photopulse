function cacheImages(){if(document.images){var imgFiles=cacheImages.arguments;if(document.imagesCache==null)document.imagesCache=new Array();var i=document.imagesCache.length;with(document)for(var j=0;j<imgFiles.length;j++){imagesCache[i]=new Image;imagesCache[i++].src="images/"+imgFiles[j]+"_F2.jpg";}}}
function on(){obj=eval("document."+on.arguments[0]);if(obj!=null){obj.src="images/"+on.arguments[0]+"_F2.jpg";}}
function off(){obj=eval("document."+off.arguments[0]);if(obj!=null){obj.src="images/"+off.arguments[0]+".jpg";}}

function header() {
document.writeln( "<body bgcolor=white onLoad=\"cacheImages('apidocs','contribute','documentation','download','examples','faq','features','feedback','home','installation','benchmark','maillist','support','history','credits','gallery')\">" );
document.writeln( "<table width=745 border=0 cellspacing=0 cellpadding=0 cols=3>" );
document.writeln( "  <th width=610></th><th width=95></th><th width=40></th>" );
document.writeln( "  <tr>" );
document.writeln( "   <td colspan=3><img src=\"images/top1.jpg\" width=745 height=90 border=0></td>" );
document.writeln( "  </tr>" );
document.writeln( "  <tr>" );
document.writeln( "   <td><img src=\"images/top2.jpg\" width=610 height=20 border=0></td>" );
document.writeln( "   <td><a href=\"mailto:skavish@usa.net\"><img src=\"images/dskavish.jpg\" width=95 height=20 border=0 alt=\"skavish@usa.net\"></a></td>" );
document.writeln( "   <td><img src=\"images/top3.jpg\" width=40 height=20 border=0></td>" );
document.writeln( "  </tr>" );
document.writeln( "</table>" );

document.writeln( "<table border=0 cellpadding=0 cellspacing=0 width=745>" );
document.writeln( "  <tr align=left valign=top>" );
document.writeln( "    <td align=left valign=top width=140>" );
document.writeln( "      <img src=\"images/separator_top.jpg\" width=140 height=10 border=0><br>" );
document.writeln( "      <a href=\"index.html\" onMouseOut=\"off('home');\" onMouseOver=\"on('home');\"><img name=home src=\"images/home.jpg\" width=140 height=20 border=0 alt=\"Home\"></a><br>" );
document.writeln( "      <img src=\"images/separator.jpg\" width=140 height=10 border=0><br>" );
document.writeln( "      <a href=\"installation.html\" onMouseOut=\"off('installation');\" onMouseOver=\"on('installation');\"><img name=installation src=\"images/installation.jpg\" width=140 height=20 border=0 alt=\"Installation\"></a><br>" );
document.writeln( "      <a href=\"features.html\" onMouseOut=\"off('features');\" onMouseOver=\"on('features');\"><img name=features src=\"images/features.jpg\" width=140 height=20 border=0 alt=\"Features\"></a><br>" );
document.writeln( "      <a href=\"history.html\" onMouseOut=\"off('history');\" onMouseOver=\"on('history');\"><img name=history src=\"images/history.jpg\" width=140 height=20 border=0 alt=\"History\"></a><br>" );
document.writeln( "      <img src=\"images/separator.jpg\" width=140 height=10 border=0><br>" );
document.writeln( "      <a href=\"documentation.html\" onMouseOut=\"off('documentation');\" onMouseOver=\"on('documentation');\"><img name=documentation src=\"images/documentation.jpg\" width=140 height=20 border=0 alt=\"Documentation\"></a><br>" );
document.writeln( "      <a href=\"benchmark.html\" onMouseOut=\"off('benchmark');\" onMouseOver=\"on('benchmark');\"><img name=benchmark src=\"images/benchmark.jpg\" width=140 height=20 border=0 alt=\"Benchmark\"></a><br>" );
document.writeln( "      <a href=\"faq.html\" onMouseOut=\"off('faq');\" onMouseOver=\"on('faq');\"><img name=faq src=\"images/faq.jpg\" width=140 height=20 border=0 alt=\"FAQ\"></a><br>" );
document.writeln( "      <a href=\"apidocs.html\" onMouseOut=\"off('apidocs');\" onMouseOver=\"on('apidocs');\"><img name=apidocs src=\"images/apidocs.jpg\" width=140 height=20 border=0 alt=\"API Docs\"></a><br>" );
document.writeln( "      <a href=\"examples.html\" onMouseOut=\"off('examples');\" onMouseOver=\"on('examples');\"><img name=examples src=\"images/examples.jpg\" width=140 height=20 border=0 alt=\"Examples\"></a><br>" );
document.writeln( "      <a href=\"gallery.html\" onMouseOut=\"off('gallery');\" onMouseOver=\"on('gallery');\"><img name=gallery src=\"images/gallery.jpg\" width=140 height=20 border=0 alt=\"Gallery\"></a><br>" );
document.writeln( "      <img src=\"images/separator.jpg\" width=140 height=10 border=0><br>" );
document.writeln( "      <a href=\"download.shtml\" onMouseOut=\"off('download');\" onMouseOver=\"on('download');\"><img name=download src=\"images/download.jpg\" width=140 height=20 border=0 alt=\"Download\"></a><br>" );
document.writeln( "      <a href=\"contribute.html\" onMouseOut=\"off('contribute');\" onMouseOver=\"on('contribute');\"><img name=contribute src=\"images/contribute.jpg\" width=140 height=20 border=0 alt=\"Contribute\"></a><br>" );
document.writeln( "      <img src=\"images/separator.jpg\" width=140 height=10 border=0><br>" );
document.writeln( "      <a href=\"maillist.html\" onMouseOut=\"off('maillist');\" onMouseOver=\"on('maillist');\"><img name=maillist src=\"images/maillist.jpg\" width=140 height=20 border=0 alt=\"Maillist\"></a><br>" );
document.writeln( "      <a href=\"feedback.html\" onMouseOut=\"off('feedback');\" onMouseOver=\"on('feedback');\"><img name=feedback src=\"images/feedback.jpg\" width=140 height=20 border=0 alt=\"Feedback\"></a><br>" );
document.writeln( "      <a href=\"support.html\" onMouseOut=\"off('support');\" onMouseOver=\"on('support');\"><img name=support src=\"images/support.jpg\" width=140 height=20 border=0 alt=\"Support\"></a><br>" );
document.writeln( "      <a href=\"credits.html\" onMouseOut=\"off('credits');\" onMouseOver=\"on('credits');\"><img name=credits src=\"images/credits.jpg\" width=140 height=20 border=0 alt=\"Credits\"></a><br>" );
document.writeln( "      <img src=\"images/separator_bottom.jpg\" width=140 height=45 border=0><br>" );
document.writeln( "      <br><br>" );
document.writeln( "      <center><a href=\"http://sourceforge.net\"><img src=\"http://sourceforge.net/sflogo.php?group_id=19191&type=1\" width=88 height=31 border=0 alt=\"SourceForge Logo\"></a></center><br>" );
document.writeln( "    </td>" );
document.writeln( "    <td align=left valign=top>" );
}

function footer() {
document.writeln( " </td>" );
document.writeln( "  </tr>" );
document.writeln( "  <tr>" );
document.writeln( "    <td>&nbsp;</td>" );
document.writeln( " <td>" );
//document.writeln( "<br> " );
document.writeln( "<img src=\"images/blackdot.gif\" width=605 height=1>" );
document.writeln( "<table border=0 cellpadding=0 cellspacing=0 width=605>" );
document.writeln( "<tr><td class=copyright align=left valign=top>Copyright (c) <a href=\"mailto:skavish@usa.net\">Dmitry Skavish</a> 2000</td>" );
document.writeln( "<td class=copyright align=right valign=top>Design by <a href=\"mailto:skavishka@hotmail.com\">Katya Skavish</a></td></tr>" );
document.writeln( "</table>" );
document.writeln( " </td>" );
document.writeln( "  </tr>" );
document.writeln( "</table>" );

document.writeln( "</body>" );
}

