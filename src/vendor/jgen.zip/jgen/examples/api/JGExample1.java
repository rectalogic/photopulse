/*
 * The JGenerator Software License, Version 1.0
 *
 * Copyright (c) 2000 Dmitry Skavish (skavish@usa.net). All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *    "This product includes software developed by Dmitry Skavish
 *     (skavish@usa.net, http://www.flashgap.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The name "The JGenerator" must not be used to endorse or promote
 *    products derived from this software without prior written permission.
 *    For written permission, please contact skavish@usa.net.
 *
 * 5. Products derived from this software may not be called "The JGenerator"
 *    nor may "The JGenerator" appear in their names without prior written
 *    permission of Dmitry Skavish.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL DMITRY SKAVISH OR THE OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

import java.io.*;
import java.util.*;
import java.awt.geom.*;

import com.iv.flash.api.*;
import com.iv.flash.api.shape.*;
import com.iv.flash.parser.*;
import com.iv.flash.util.*;

/**
 * Draws a rectangle with a stroke
 *
 * Steps:
 *  - create file and main script
 *  - add first frame to the script
 *  - create shape
 *  - add fill and line styles to the shape
 *  - choose just added styles for drawing
 *  - draw rectangle
 *  - set bounding box
 *  - add instance (placeobject) of the shape to the frame
 *  - generate the file
 *
 */
public class JGExample1 extends JGExample {

    public JGExample1( int rect_size, int stroke_width, AlphaColor rect_color, AlphaColor stroke_color ) {
        // create default flash file
        FlashFile file = FlashFile.newFlashFile();

        Script script = new Script(1);      // create main script with 1 frame
        script.setMain();
        file.setMainScript( script );       // set main script for the file

        Frame frame = script.newFrame();        // create new frame and add to the end of the timeline

        // create shape rectangle
        Shape shape = new Shape();

        // set fill and line style
        shape.setLineStyle( new LineStyle( stroke_width, stroke_color ) );
        shape.setFillStyle0( FillStyle.newSolid( rect_color ) );

        /* the following code is equivalent to the above but more generic

            // add stroke color and size (linestyle)
            int line_style = shape.addLineStyle( new LineStyle( stroke_width, stroke_color ) );
            // add fill color
            int fill_style = shape.addFillStyle( FillStyle.newSolid( rect_color ) );
            // choose previously added line and fill styles
            shape.setLineStyle( line_style );
            shape.setFillStyle0( fill_style );

        */

        Rectangle2D r = GeomHelper.newRectangle( 0, 0, rect_size, rect_size ); // create Rect for the rectangle
        //s.drawRectangle( rect_size, rect_size, rect_size, rect_size );
        shape.drawRectangle( r );                                           // draw rectangle (it's rather square :))
        shape.setBounds( r );                                           // set bounding box for the shape

        // add instance of the shape to the frame, to layer 1, with id matrix and color transform
        frame.addInstance(shape, 1, new AffineTransform(), null);

        // generate swf
        generate( "example1.swf", file );
    }

    public static void main( String[] args ) {
        init();
        JGExample ex = new JGExample1( 50*20, 6*20, AlphaColor.red, AlphaColor.blue );
    }
}
