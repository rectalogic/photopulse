import java.io.*;
import java.util.*;
import java.awt.geom.*;

import com.iv.flash.api.*;
import com.iv.flash.api.action.*;
import com.iv.flash.api.shape.*;
import com.iv.flash.parser.*;
import com.iv.flash.util.*;

/**
 * Example of AS jumps without ASAssembler
 */
public class JGExample9 extends JGExample {

    static String[] values = { "Home",                    "Contact" };
    static String[] urls   = { "http://www.flashgap.com", "http://www.google.com" };

    public JGExample9() {
        // create default flash file
        FlashFile file = FlashFile.newFlashFile();

        Script script = new Script(1);      // create main script with 1 frame
        script.setMain();
        file.setMainScript( script );       // set main script for the file

        Frame frame = script.newFrame();

        Program p = new Program();
        DoAction ac = new DoAction(p);
        FlashBuffer fb = p.body();

        p.push("quicklink");
        p.push("Contact");
        p.setVar();

        for( int i=0; i<values.length; i++ ) {
            p.push("quicklink");
            p.getVar();
            p.push(values[i]);
            //p.equal();
            fb.writeByte(Actions.Equals2);
            p.logicalNot();
            // if
            p.jumpIfTrue(0);

                int pos = fb.getPos();   // remember position just after jump
                p.getURL(urls[i], "_blank");

            // endif
            fb.writeWordAt(fb.getPos()-pos, pos-2);
        }

        frame.addFlashObject(ac);

        // generate swf
        generate( "example9.swf", file );
    }

    public static void main( String[] args ) {
        init();
        JGExample ex = new JGExample9();
    }
}




