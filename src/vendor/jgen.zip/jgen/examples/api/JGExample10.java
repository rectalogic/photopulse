import java.io.*;
import java.util.*;
import java.awt.geom.*;

import com.iv.flash.api.*;
import com.iv.flash.api.action.*;
import com.iv.flash.api.shape.*;
import com.iv.flash.api.text.*;
import com.iv.flash.parser.*;
import com.iv.flash.util.*;

/**
 * Example of advanced actionscripting using ASAssembler
 */
public class JGExample10 extends JGExample {

    static String[] values = { "Home",                    "Contact" };
    static String[] urls   = { "http://www.flashgap.com", "http://www.google.com" };

    public JGExample10() {
        // create default flash file
        FlashFile file = FlashFile.newFlashFile();
        file.setVersion(5); // !!! important

        Script script = new Script(1);      // create main script with 1 frame
        script.setMain();
        file.setMainScript( script );       // set main script for the file

        // Frame #0
        Frame frame = script.newFrame();
        ASAssembler as = new ASAssembler(file);

        // function printmsg(msg, name) {
        //    trace(msg+", "+name);
        // }
        as.defineFunction("printmsg", new String[] {"msg", "name"});
            as.getVar("name");
            as.push(" = ");
            as.getVar("msg");
            as.add();
            as.add();
            as.trace();
        as.endFunction();


        // quicklink = "Contact";
        as.setVar("quicklink", "Contact");

        for( int i=0; i<values.length; i++ ) {
            as.push(values[i]);
            as.getVar("quicklink");
            as.equal();
            as.logicalNot();
            // if
            as.jumpIfTrue("end"+i);
                as.getURL(urls[i], "_blank");
            as.label("end"+i);
            // endif
        }

        as.setVar("cursin", new Integer(0));
        as.setVar("myfield", "start");

        frame.addFlashObject(new DoAction(as.toProgram()));

        // Frame #1
        frame = script.newFrame();

        as = new ASAssembler(file);

        // myfield = Math.sin(cursin);
        as.push("myfield");
        as.callMethod("Math.sin", new Object[] {
            new ASAssembler.Expr() {
                public void eval( ASAssembler as ) {
                    as.getVar("cursin");
                }
            }
        });
        as.setVar();
        // cursin = cursin + 0.2;
        as.push("cursin");
        as.push(0.2);
        as.getVar("cursin");
        as.add();
        as.setVar();
        // helloworld("Math.sin", myfield);
        as.callFunction("printmsg", new Object[] {"Math.sin", new ASAssembler.Expr() {
                public void eval( ASAssembler as ) {
                    as.getVar("myfield");
                }
            }
        });

        frame.addFlashObject(new DoAction(as.toProgram()));

        // create text field with variable 'myfield'
        Font font = FontDef.load("Arial.fft");
        TextField tf = new TextField("first", "myfield", font, 12*20, AlphaColor.blue);
        //tf.setLayout(0, 0, 0, 0, 40);
        tf.setBounds(GeomHelper.newRectangle(0, 0, 100*20, 30*20));
        frame.addInstance(tf, 1, AffineTransform.getTranslateInstance(100*20, 100*20), null);

        // Frame #2
        frame = script.newFrame();
        as = new ASAssembler(file);
        as.gotoFrame(1);
        as.play();
        frame.addFlashObject(new DoAction(as.toProgram()));

        // generate swf
        generate( "example10.swf", file );
    }

    public static void main( String[] args ) {
        init();
        JGExample ex = new JGExample10();
    }
}





