/*
 * The JGenerator Software License, Version 1.0
 *
 * Copyright (c) 2000 Dmitry Skavish (skavish@usa.net). All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *    "This product includes software developed by Dmitry Skavish
 *     (skavish@usa.net, http://www.flashgap.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The name "The JGenerator" must not be used to endorse or promote
 *    products derived from this software without prior written permission.
 *    For written permission, please contact skavish@usa.net.
 *
 * 5. Products derived from this software may not be called "The JGenerator"
 *    nor may "The JGenerator" appear in their names without prior written
 *    permission of Dmitry Skavish.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL DMITRY SKAVISH OR THE OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

import java.io.*;
import java.util.*;
import java.awt.geom.*;

import com.iv.flash.api.*;
import com.iv.flash.api.shape.*;
import com.iv.flash.api.action.*;
import com.iv.flash.api.button.*;
import com.iv.flash.api.text.*;
import com.iv.flash.parser.*;
import com.iv.flash.util.*;

/**
 * Create a button
 *
 * Steps:
 *  - create file and main script
 *  - create button's background (rectangular shape)
 *  - create button text
 *  - create Up state
 *  - create Over and Down state with reduced brighntess
 *  - create Hit state
 *  - create action condition
 *  - create frame and add button to it
 *  - generate the file
 *
 */
public class JGExample4 extends JGExample {

    public static final int WIDTH   = 100*20;
    public static final int HEIGHT  = 25*20;

    public JGExample4() {
        // create default flash file
        FlashFile file = FlashFile.newFlashFile();

        Script script = new Script(1);      // create main script with 1 frame
        script.setMain();
        file.setMainScript( script );       // set main script for the file

        //--------------------------------------------------
        // create rectangular background for button
        //--------------------------------------------------
        Shape shape = new Shape();
        shape.setLineStyle( new LineStyle( 2*20, AlphaColor.black ) );
        shape.setFillStyle0( FillStyle.newSolid( new AlphaColor(0x31, 0x63, 0x9c, 0xe0) ));
        Rectangle2D r = GeomHelper.newRectangle( 0, 0, WIDTH, HEIGHT );
        shape.drawRectangle( r );
        shape.setBounds( r );

        AffineTransform shapeMatrix = new AffineTransform();
        AffineTransform textMatrix = new AffineTransform();
        textMatrix.translate(0,2*20);

        //--------------------------------------------------
        // create text for button
        //--------------------------------------------------
        Font font = FontDef.load( "AgencyGFB.fft", file );
        Text text = Text.newText();
        TextItem item = new TextItem( "The JGenerator", font, 18*20, AlphaColor.white );
        item.align = 2;     // center
        text.addTextItem( item );
        text.setBounds( GeomHelper.newRectangle(0, 0, WIDTH, HEIGHT) );

        //--------------------------------------------------
        // create button
        //--------------------------------------------------
        Button2 button = new Button2();

        //--------------------------------------------------
        // create Up state
        //--------------------------------------------------
        ButtonRecord upState0 =
            new ButtonRecord( ButtonRecord.Up, shape, 1, shapeMatrix, CXForm.newIdentity(true) );
        ButtonRecord upState1 =
            new ButtonRecord( ButtonRecord.Up, text, 2, textMatrix, CXForm.newIdentity(true) );

        button.addButtonRecord(upState0);
        button.addButtonRecord(upState1);

        //--------------------------------------------------
        // create Over and Down state with reduced brightness
        //--------------------------------------------------
        ButtonRecord overdownState0 =
            new ButtonRecord( ButtonRecord.Over|ButtonRecord.Down, shape, 1, shapeMatrix, CXForm.newBrightness(-0.3, true) );
        ButtonRecord overdownState1 =
            new ButtonRecord( ButtonRecord.Over|ButtonRecord.Down, text, 2, textMatrix, CXForm.newBrightness(-0.1, true) );

        button.addButtonRecord(overdownState0);
        button.addButtonRecord(overdownState1);

        //--------------------------------------------------
        // create Hit state
        //--------------------------------------------------
        ButtonRecord hitState =
            new ButtonRecord( ButtonRecord.HitTest, shape, 1, shapeMatrix, CXForm.newIdentity(true) );

        button.addButtonRecord(hitState);

        //--------------------------------------------------
        // create action getUrl("http://www.flashgap.com") on release
        //--------------------------------------------------
        Program getUrl = new Program();
        getUrl.getURL("http://www.flashgap.com", "_blank");
        getUrl.stop();
        ActionCondition onRelease = new ActionCondition(ActionCondition.OverDownToOverUp, getUrl);

        button.addActionCondition(onRelease);

        //--------------------------------------------------
        // create frame and put the button there
        //--------------------------------------------------
        Frame frame = script.newFrame();
        AffineTransform toCenter = new AffineTransform();
        toCenter.translate( file.getFrameSize().getWidth()/2-WIDTH/2, file.getFrameSize().getHeight()/2-HEIGHT/2 );
        frame.addInstance(button, 1, toCenter, null);

        // generate swf
        generate( "example4.swf", file );
    }

    public static void main( String[] args ) {
        init();
        JGExample ex = new JGExample4();
    }
}
